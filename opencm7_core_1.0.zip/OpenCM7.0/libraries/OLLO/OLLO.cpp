/*
 * OLLO.cpp
 *
 *  Created on: 2013. 5. 30.
 *      Author: ROBOTIS,.LTD.
 */

#include "OLLO.h"

#include "Arduino-compatibles.h"

uint8 before_color_num =0;
uint8 before_color_cnt =0;
uint8 after_color_value = 0;
uint8 bColorResult =0;

OLLO::OLLO() {
	// TODO Auto-generated constructor stub
	mMot_setup = 0;
}
/*  // jason commented temp
OLLO::~OLLO() {
	// TODO Auto-generated destructor stub
}
*/

int average_cnt = 0;
word long gwTheRmistor[108] = {
  67747,64577,61571,58721,
  56017,53452,51018,48707,
  46513,44430,42450,40569,
  38781,37081,35465,33927,
  32464,31072,29747,28485,
  27283,26138,25048,24008, 23017,
  22072,21171,20311,19491,
  18708,17960,17246,16565,
  15913,15291,14696,14128,
  13584,13064,12567,12091,
  11636,11200,10782,10383,
  10000, 9633, 9282,  8945,
  8622, 8313, 8016, 7731,
  7458, 7195, 6944, 6702,
  6470, 6247, 6033, 5828,
  5630, 5440, 5258, 5082,
  4914, 4751, 4595, 4445,
  4300, 4161, 4027, 3898,
  3774, 3654, 3539, 3427,
  3320, 3217, 3118, 3022,
  2929, 2840, 2754, 2671,
  2590, 2513, 2438, 2366,
  2296, 2229, 2164, 2101,
};

void OLLO::begin(int devNum){
	if( devNum == 0 ){
			return;
	}
	mMot_plus = 0;
	mMot_minus = 0;

	switch(devNum){
	case 1:
		if(mMot_setup == 0)
		{
			mMot_setup = 1;
			Timer11.pause();
			Timer11.setPeriod(120);
			Timer11.setMode(TIMER_CH1, TIMER_OUTPUT_COMPARE);
			Timer11.setCompare(TIMER_CH1, 1);
			Timer11.refresh();
			Timer11.resume();
		}
		pinMode(PORT1_SIG2, OUTPUT);
		pinMode(PORT1_SIG1, OUTPUT);
		break;
	case 2:
		if(mMot_setup == 0)
		{
			mMot_setup = 1;
			Timer11.pause();
			Timer11.setPeriod(120);
			Timer11.setMode(TIMER_CH1, TIMER_OUTPUT_COMPARE);
			Timer11.setCompare(TIMER_CH1, 1);
			Timer11.refresh();
			Timer11.resume();
		}
		pinMode(PORT2_SIG2, OUTPUT);
		pinMode(PORT2_SIG1, OUTPUT);
		break;
	case 3:
		gpio_set_mode(GPIOB_DEV, 2, GPIO_OUTPUT_PP);
		pinMode(PORT3_SIG1, OUTPUT); //BLUE (left)
		pinMode(PORT3_ADC, INPUT_ANALOG); //ADC input
		break;
	case 4:
		pinMode(PORT4_SIG2, OUTPUT); //RED  (right)
		pinMode(PORT4_SIG1, OUTPUT); //BLUE (left)
		pinMode(PORT4_ADC, INPUT_ANALOG);//ADC input
		break;
	case 5:
		pinMode(PORT5_SIG2, OUTPUT); //RED  (right)
		pinMode(PORT5_SIG1, OUTPUT); //BLUE (left)
		pinMode(PORT5_ADC, INPUT_ANALOG);//ADC input
		break;
	case 6:
		pinMode(PORT6_SIG2, OUTPUT); //RED  (right)
		pinMode(PORT6_SIG1, OUTPUT); //BLUE (left)
		pinMode(PORT6_ADC, INPUT_ANALOG);//ADC input
		break;
	default:
		break;
	}
}
void OLLO::begin(int devNum, int device_index){ //MAGNETIC SENSOR, Button, IR Sensor, and etc...
	if( devNum == 0 ){
			return;
	}
	mMot_plus = 0;
	mMot_minus = 0;
	if(device_index == GEARED_MOTOR || device_index == SERVO_MOTOR)
	{
		if(mMot_setup == 0)
		{
			mMot_setup = 1;
			Timer11.pause();
			Timer11.setPeriod(120);
			Timer11.setMode(TIMER_CH1, TIMER_OUTPUT_COMPARE);
			Timer11.setCompare(TIMER_CH1, 1);
			Timer11.refresh();
			Timer11.resume();
		}
	}
	switch(devNum){
	case 1:
		if(device_index == GEARED_MOTOR){
			pinMode(PORT1_SIG2, OUTPUT);
			pinMode(PORT1_SIG1, OUTPUT);
		}
		break;
	case 2:
		if(device_index == GEARED_MOTOR){
			pinMode(PORT2_SIG2, OUTPUT);
			pinMode(PORT2_SIG1, OUTPUT);
		}
		break;
	case 3:
		if(device_index == MAGNETIC_SENSOR){
			pinMode(PORT3_ADC, INPUT); //digital input
		}else if(device_index == TOUCH_SENSOR){
			pinMode(PORT3_ADC, INPUT_PULLUP);
		}else{
			pinMode(PORT3_ADC, INPUT_ANALOG); //ADC input
		}

		//pinMode(PORT3_SIG2, OUTPUT); //SIG2
		gpio_set_mode(GPIOB_DEV, 2, GPIO_OUTPUT_PP);
		pinMode(PORT3_SIG1, OUTPUT); //SIG1
		if(device_index == IR_SENSOR ){
			//digitalWrite(PORT3_SIG2,HIGH); //SIG2 set to LOW
			gpio_write_bit(GPIOB_DEV, 2, HIGH);
			digitalWrite(PORT3_SIG1,HIGH); //SIG1 set to LOW
		}
		break;
	case 4:
		if(device_index == MAGNETIC_SENSOR){
			pinMode(PORT4_ADC, INPUT); //digital input
		}else if(device_index == TOUCH_SENSOR){
			pinMode(PORT4_ADC, INPUT_PULLUP);
		}else{
			pinMode(PORT4_ADC, INPUT_ANALOG);//ADC input
		}


		pinMode(PORT4_SIG2, OUTPUT); //SIG2
		pinMode(PORT4_SIG1, OUTPUT); //SIG1
		if(device_index == IR_SENSOR ){
			digitalWrite(PORT4_SIG2,HIGH); //set to LOW
			digitalWrite(PORT4_SIG1,HIGH); //set to LOW
		}
		break;
	case 5:
		if(device_index == MAGNETIC_SENSOR){
			pinMode(PORT5_ADC, INPUT); //digital input
		}else if(device_index == TOUCH_SENSOR){
			pinMode(PORT5_ADC, INPUT_PULLUP);
		}else{
			pinMode(PORT5_ADC, INPUT_ANALOG);//ADC input
		}


		pinMode(PORT5_SIG2, OUTPUT); //SIG2
		pinMode(PORT5_SIG1, OUTPUT); //SIG1
		if(device_index == IR_SENSOR ){
			digitalWrite(PORT5_SIG2,HIGH); //set SIG2 to LOW
			digitalWrite(PORT5_SIG1,HIGH); //set SIG1 to LOW
		}
		break;
	case 6:
		if(device_index == MAGNETIC_SENSOR){
			pinMode(PORT6_ADC, INPUT); //digital input
		}else if(device_index == TOUCH_SENSOR){
			pinMode(PORT6_ADC, INPUT_PULLUP);
		}else{
			pinMode(PORT6_ADC, INPUT_ANALOG);//ADC input
		}


		pinMode(PORT6_SIG2, OUTPUT); //SIG2
		pinMode(PORT6_SIG1, OUTPUT); //SIG1
		if(device_index == IR_SENSOR ){
			digitalWrite(PORT6_SIG2,HIGH); //set SIG2 to LOW
			digitalWrite(PORT6_SIG1,HIGH); //set SIG1 to LOW
		}
		break;
	default:
		break;
	}
}

void OLLO::begin(int devNum, int device_index, voidFuncPtr handler){ //Button with handler function.
	if( devNum == 0 ){
		return;
	}
	switch(devNum){
	case 3:
		if(device_index == TOUCH_SENSOR){
			pinMode(PORT3_ADC, INPUT_PULLUP);
			attachInterrupt(PORT3_ADC,handler, RISING);
		}
		break;
	case 4:
		if(device_index == TOUCH_SENSOR){
			pinMode(PORT4_ADC, INPUT_PULLUP);
			attachInterrupt(PORT4_ADC,handler, RISING);
		}
		break;
	case 5:
		if(device_index == TOUCH_SENSOR){
			pinMode(PORT5_ADC, INPUT_PULLUP);
			attachInterrupt(PORT5_ADC,handler, RISING);
		}
		break;
	case 6:
		if(device_index == TOUCH_SENSOR){
			pinMode(PORT6_ADC, INPUT_PULLUP);
			attachInterrupt(PORT6_ADC,handler, RISING);
		}
		break;
	default:
		break;
	}
}


int OLLO::read(int devNum){ // general sensor reading method
	if( devNum == 0 ){
			return 0;
	}
	switch(devNum){
	case 3:
		return (int)analogRead(PORT3_ADC);
	case 4:
		return (int)analogRead(PORT4_ADC);
	case 5:
		return (int)analogRead(PORT5_ADC);
	case 6:
		return (int)analogRead(PORT6_ADC);
	default:
		return 0;
	}

}
int OLLO::read(int devNum, int device_index){ // IR SENSOR, Button, MAGNETIC SENSOR, and etc...
	int adcValue = 0;
	signed int scount;
	word  vvalue = 0;
	word analogValue;
	if( devNum == 0 ){
		return 0;
	}
	switch(devNum){
	case 3:
		if(device_index == IR_SENSOR){
			digitalWrite(PORT3_SIG1, LOW);
			delayMicroseconds(15);
			adcValue = analogRead(PORT3_ADC);
			digitalWrite(PORT3_SIG1, HIGH);
			return adcValue;
		}else if(device_index == MAGNETIC_SENSOR || device_index == TOUCH_SENSOR ){
			return digitalRead(PORT3_ADC);
		}else if(device_index == PIR_SENSOR ){
			return (analogRead(PORT3_ADC) < 2300 ? 1:0);
		}else if(device_index == TEMPERATURE_SENSOR){
			analogValue = analogRead(PORT3_ADC);
			vvalue = (4095 - analogValue) * 10000 /analogValue;
			for(scount = -20; scount < 140; scount++){
				if(vvalue > gwTheRmistor[scount +20]){
				      return scount;
				}
			}
		}else if(device_index == COLOR_SENSOR){
			return this->detectColor(3);
		}else{
			return (int)analogRead(PORT3_ADC);
		}
		break;
	case 4:
		if(device_index == IR_SENSOR){
			digitalWrite(PORT4_SIG1, LOW);
			delayMicroseconds(15);
			adcValue = analogRead(PORT4_ADC);
			digitalWrite(PORT4_SIG1, HIGH);
			return adcValue;
		}else if(device_index == MAGNETIC_SENSOR || device_index == TOUCH_SENSOR ){
			return digitalRead(PORT4_ADC);
		}else if(device_index == PIR_SENSOR ){
			return (analogRead(PORT4_ADC) < 2300 ? 1:0);
		}else if(device_index == TEMPERATURE_SENSOR){
			analogValue = analogRead(PORT4_ADC);
			vvalue = (4095 - analogValue) * 10000 /analogValue;
			for(scount = -20; scount < 140; scount++){
				if(vvalue > gwTheRmistor[scount +20]){
				      return scount;
				}
			}
		}else if(device_index == COLOR_SENSOR){
			return this->detectColor(4);
		}else{
			return (int)analogRead(PORT4_ADC);
		}
		break;
	case 5:
		if(device_index == IR_SENSOR){
			digitalWrite(PORT5_SIG1, LOW);
			delayMicroseconds(15);
			adcValue = analogRead(PORT5_ADC);
			digitalWrite(PORT5_SIG1, HIGH);
			return adcValue;
		}else if(device_index == MAGNETIC_SENSOR || device_index == TOUCH_SENSOR ){
			return digitalRead(PORT5_ADC);
		}else if(device_index == PIR_SENSOR ){
			return (analogRead(PORT5_ADC) < 2300 ? 1:0);
		}else if(device_index == TEMPERATURE_SENSOR){
			analogValue = analogRead(PORT5_ADC);
			vvalue = (4095 - analogValue) * 10000 /analogValue;
			for(scount = -20; scount < 140; scount++){
				if(vvalue > gwTheRmistor[scount +20]){
				      return scount;
				}
			}
		}else if(device_index == COLOR_SENSOR){
			return this->detectColor(5);
		}else{
			return (int)analogRead(PORT5_ADC);
		}
		break;
	case 6:
		if(device_index == IR_SENSOR){
			digitalWrite(PORT6_SIG1, LOW);
			delayMicroseconds(15);
			adcValue = analogRead(PORT6_ADC);
			digitalWrite(PORT6_SIG1, HIGH);
			return adcValue;
		}else if(device_index == MAGNETIC_SENSOR || device_index == TOUCH_SENSOR ){
			return digitalRead(PORT6_ADC);
		}else if(device_index == PIR_SENSOR ){
			return (analogRead(PORT6_ADC) < 2300 ? 1:0);
		}else if(device_index == TEMPERATURE_SENSOR){
			analogValue = analogRead(PORT6_ADC);
			vvalue = (4095 - analogValue) * 10000 /analogValue;
			for(scount = -20; scount < 140; scount++){
				if(vvalue > gwTheRmistor[scount +20]){
				      return scount;
				}
			}
		}else if(device_index == COLOR_SENSOR){
			return this->detectColor(6);
		}else{
			return (int)analogRead(PORT6_ADC);
		}
		break;
	default:
		return 0;
	}
	return 0;
}

int OLLO::read(int devNum, OlloDeviceIndex device_index, ColorIndex sub_index){ //COLOR SENSOR
	//int adcValue = 0;
	if( devNum == 0 ){
		return 0;
	}
	if(device_index == COLOR_SENSOR){
		this->setColor(sub_index);
	}else{
		return 0;
	}

	switch(devNum){
	case 3:
		 //digitalWrite(PORT3_SIG2, mMot_plus);
		 gpio_write_bit(GPIOB_DEV, 2, mMot_plus);
		 digitalWrite(PORT3_SIG1,mMot_minus);
		 delay(20); // after 20ms, read analog
		 return (int)analogRead(PORT3_ADC);

	case 4:
		digitalWrite(PORT4_SIG2, mMot_plus);
		digitalWrite(PORT4_SIG1, mMot_minus);
		delay(20);
		return (int)analogRead(PORT4_ADC);

	case 5:
		digitalWrite(PORT5_SIG2, mMot_plus);
		digitalWrite(PORT5_SIG1, mMot_minus);
		delay(20);
		return (int)analogRead(PORT5_ADC);

	case 6:
		digitalWrite(PORT6_SIG2, mMot_plus);
		digitalWrite(PORT6_SIG1, mMot_minus);
		delay(20);
		return (int)analogRead(PORT6_ADC);

	default:
		return 0;
	}
}


int OLLO::detectColor(uint8 port){

	int temp_red,temp_green,temp_blue;

	temp_red = 0;
	temp_green = 0;
	temp_blue= 0;
	int lColor[3]= {0,0,0};
	int lRed,lGreen,lBlue;
	int bMaxColor, bMinColor, bColorResult;
	bMaxColor=0;
	bMinColor=0;
	bColorResult=0;

	lRed = this->read(port, COLOR_SENSOR, RED)/4;
//for(i=0; i < 3; i++)

	lGreen = (this->read(port, COLOR_SENSOR, GREEN))/4;
//for(i=0; i < 3; i++)

	lBlue = this->read(port, COLOR_SENSOR, BLUE)/4;

	if(lRed >= lGreen && lRed >= lBlue)
	{
	       bMaxColor = 1;
	       lColor[0] = lRed;
	}
	else if(lGreen >= lRed && lGreen >= lBlue)
	{
	       bMaxColor = 2;
	       lColor[0] = lGreen;
	}

	else if(lBlue >= lRed && lBlue >= lGreen)
	{
	       bMaxColor = 3;
	       lColor[0] = lBlue;
	}
	if(lRed <= lGreen && lRed <= lBlue)
	{
	       bMinColor = 1;
	       lColor[2] = lRed;
	}
	else if(lGreen <= lRed && lGreen <= lBlue)
	{
	       bMinColor = 2;
	       lColor[2] = lGreen;
	}

	else if(lBlue <= lRed && lBlue <= lGreen)
	{
	       bMinColor = 3;
	       lColor[2] = lBlue;
	}

	lColor[1] = lRed + lGreen + lBlue - lColor[0] - lColor[2];

	u32 RtoB = lRed * 100 / lBlue;
	u32 GtoB = lGreen * 100 / lBlue;
	u32 GtoR = lGreen * 100 / lRed;

//2014-03-24 sm6787@robotis.com
	if(lColor[0] < 90 || ( lColor[0] < 180 				 &&
						   RtoB > 60 					 &&
						   (GtoB < 110 || GtoR < 130) 	 &&
						   (GtoB + GtoR < 230)  		 /*&&
						   ((lColor[2] * 100 / lColor[0]) > 75)*/
						  )
	   ){//end of if()
	       bColorResult = 2; // blackz
	}
	else if((lColor[2] > 550) || ((lColor[2] > 200) && (lColor[0] > 300) && (lColor[2] * 100 / lColor[0] > 75) && (GtoB < 105)))
	       bColorResult = 1; // white
	else if(RtoB > 170 && GtoB > 130)
	       bColorResult = 6; // yellow
	else if(RtoB > 170 && GtoB <= 130)
	       bColorResult = 3; // red
	else if(GtoB > 90 && GtoR >= 110)//90 110
	       bColorResult = 4; // green
	else if(RtoB < 70 && GtoB <= 85)
	       bColorResult = 5; // blue
	else
	       bColorResult = 0; // unknown

	return bColorResult;

	/*
	if(bColorResult == before_color_num){
		before_color_cnt++;
		if(before_color_cnt >= 10){
			//before_color_cnt = 0;
			return bColorResult;
		}
	}
	else{
		before_color_cnt = 0;
	}

	before_color_num = bColorResult;	
	return 0;
	*/
}

void OLLO::writeLED(int devNum, uint8 rightVal, uint8 leftVal ){
	if( leftVal >1 || rightVal >1 || devNum == 0 ){
		return;
	}

	switch(devNum){
		case 3:
			gpio_write_bit(GPIOB_DEV, 2, rightVal);
			digitalWrite(PORT3_SIG1,leftVal);
			break;
		case 4:
			digitalWrite(PORT4_SIG2,rightVal);
			digitalWrite(PORT4_SIG1,leftVal);
			break;
		case 5:
			digitalWrite(PORT5_SIG2,rightVal);
			digitalWrite(PORT5_SIG1,leftVal);
			break;
		case 6:
			digitalWrite(PORT6_SIG2,rightVal);
			digitalWrite(PORT6_SIG1,leftVal);
			break;
		default:
			break;
		}

}

void OLLO::writeMotor(int devNum, MotorParameterIndex motor_parameter, uint8 direction, uint16 value){
	if( devNum == 0){
		return;
	}else if(motor_parameter == MOTOR_SPEED && (direction > 1 || value > 1023)){
		return;
	}else if(motor_parameter == MOTOR_POSITION && value > 1023){
		return;
	}else if(motor_parameter == MOTOR_MODE && value > 1){
		return;
	}

	switch(devNum){
		case 1:
		case 2:
			if(motor_parameter == MOTOR_SPEED){
				setMotorSpeed(devNum, direction, value);
			}
			break;
		case 3:
		case 4:
		case 5:
		case 6:
			if(motor_parameter == MOTOR_SPEED){
				setMotorSpeed(devNum, direction, value);
			}else if(motor_parameter == MOTOR_POSITION){
				setMotorPosition(devNum, value);
			}else if(motor_parameter == MOTOR_MODE){
				setMotorMode(devNum, (uint8)value);
			}
			break;
		default:
			break;
		}

}

void OLLO::write(int devNum, uint8 rightVal, uint8 leftVal ){
	if( leftVal >1 || rightVal >1 || devNum == 0 ){
		return;
	}

	switch(devNum){
		case 3:
			gpio_write_bit(GPIOB_DEV, 2, rightVal);
			digitalWrite(PORT3_SIG1,leftVal);
			break;
		case 4:
			digitalWrite(PORT4_SIG2,rightVal);
			digitalWrite(PORT4_SIG1,leftVal);
			break;
		case 5:
			digitalWrite(PORT5_SIG2,rightVal);
			digitalWrite(PORT5_SIG1,leftVal);
			break;
		case 6:
			digitalWrite(PORT6_SIG2,rightVal);
			digitalWrite(PORT6_SIG1,leftVal);
			break;
		default:
			break;
		}

}
void OLLO::write(int devNum, uint8 leftVal, uint8 centerVal, uint8 rightVal){

	if( leftVal >1 || rightVal >1 || centerVal > 1 || devNum == 0){
		return;
	}

	switch(devNum){
		case 3:
	         gpio_write_bit(GPIOB_DEV, 2, rightVal);
			 digitalWrite(PORT3_ADC,centerVal);
			 digitalWrite(PORT3_SIG1,leftVal);
			break;
		case 4:
			digitalWrite(PORT4_SIG2,rightVal);
			digitalWrite(PORT3_ADC,centerVal);
			digitalWrite(PORT4_SIG1,leftVal);
			break;
		case 5:
			digitalWrite(PORT5_SIG2,rightVal);
			digitalWrite(PORT3_ADC,centerVal);
			digitalWrite(PORT5_SIG1,leftVal);
			break;
		case 6:
			digitalWrite(PORT6_SIG2,rightVal);
			digitalWrite(PORT3_ADC,centerVal);
			digitalWrite(PORT6_SIG1,leftVal);
			break;
		default:
			break;
	}

}

void OLLO::setColor(ColorIndex colorIndex){
	switch(colorIndex){
			case RED: //Red
				mMot_minus = HIGH;
				mMot_plus = HIGH;
				break;
			case GREEN://Green
				mMot_minus = LOW;
				mMot_plus = HIGH;
				break;
			case BLUE://Blue
				mMot_minus = HIGH;
				mMot_plus = LOW;
				break;
			default:
				break;
		}

}
