/*
 * OLLO.h For OpenCM7.0
 *
 *  Created on: 2013. 5. 30.
 *      Author: ROBOTIS,.LTD.
 */

#ifndef OLLO_H_
#define OLLO_H_
#include "libpandora_types.h"

#include "timer.h"

typedef enum OLLO_DEVICE_INDEX {
    IR_SENSOR,
    TOUCH_SENSOR,
    GYRO_SENOSR,
    DMS_SENSOR,
    PIR_SENSOR,
    MAGNETIC_SENSOR,
    COLOR_SENSOR,
    ULTRASONIC_SENSOR,
    LED_DISPLAY,
    TEMPERATURE_SENSOR,
	SERVO_MOTOR,
	GEARED_MOTOR
}OlloDeviceIndex;

typedef enum COLOR_INDEX {
    RED =1 ,
    GREEN,
    BLUE,
    YELLOW,
    ORANGE,
    BLACK,
    WHITE
}ColorIndex;

typedef enum MOTOR_PARAMETER_INDEX {
    MOTOR_SPEED,
	MOTOR_MODE,
	MOTOR_POSITION
}MotorParameterIndex;

#define COLOR_RED 1
#define COLOR_GREEN 2
#define COLOR_BLUE 3

#define PORT1_SIG1 28
#define PORT1_SIG2 27

#define PORT2_SIG1 9
#define PORT2_SIG2 8

#define PORT3_SIG1 24 // self edit
#define PORT3_SIG2 6
#define PORT3_ADC 5

#define PORT4_SIG1 18
#define PORT4_SIG2 25
#define PORT4_ADC 0

#define PORT5_SIG1 20
#define PORT5_SIG2 19
#define PORT5_ADC 1

#define PORT6_SIG1 10
#define PORT6_SIG2 21
#define PORT6_ADC 6

#define WHEEL_MODE 0
#define SERVO_MODE 1

#define CCW 0
#define CW  1

class OLLO {
private:
	uint8 mportNumber;
	uint8 mMot_plus;
	uint8 mMot_minus;
	uint8 mMot_setup;
	int detectColor(uint8 port);
	//int color_chk();
	void setColor(ColorIndex colorIndex);
	int read(int devNum, OlloDeviceIndex device_index, ColorIndex sub_index);
public:
	OLLO();
	/*  // jason commented temp
	virtual ~OLLO();*/
	//General 3PIN sensors
	void begin(int devNum);
	void begin(int devNum, int device_index);
	void begin(int devNum, int device_index, voidFuncPtr handler);

	int read(int devNum);
	int read(int devNum, int device_index);
//	uint8 isGreen(uint8 port);
//	uint8 isWhite(uint8 port);
//	uint8 isBlue(uint8 port);
//	uint8 isBlack(uint8 port);
//	uint8 isRed(uint8 port);
//	uint8 isYellow(uint8 port);
//	uint8 detectColor(uint8 port);

	void write(int devNum, uint8 leftVal,  uint8 rightVal);
	void write(int devNum, uint8 leftVal, uint8 centerVal, uint8 rightVal);

	void writeMotor(int devNum, MotorParameterIndex motor_parameter, uint8 direction, uint16 value);

	//IR Sensor Module
	//void beginIR(int devNum);
	//LED Module
	void writeLED(int devNum,uint8 leftVal, uint8 rightVal );
	//Button Module
	//void beginButton(int devNum,voidFuncPtr handler);
	//int readColor(int devNum, int colorIndex);
	
};

#endif /* OLLO_H_ */
