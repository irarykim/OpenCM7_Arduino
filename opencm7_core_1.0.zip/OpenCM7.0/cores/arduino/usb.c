/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 LeafLabs LLC.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

/**
 *  @brief usb-specific hardware setup, NVIC, clocks, and usb activities
 *  in the pre-attached state. includes some of the lower level callbacks
 *  needed by the usb library, like suspend,resume,init,etc
 */

#include "usb.h"
//#include "usb_lib.h"
#include "gpio.h"
////#include "usb_hardware.h"
#include "delay.h"

////#include "usb_config.h"
////#include "usb_callbacks.h"
#include "USB\USB_Lib\inc\usb_lib.h"

#include "USB\inc\common_vars.h"

#define VCOM_RX_ENDP              ENDP3
#define VCOM_RX_EPNUM             0x03
#define VCOM_RX_ADDR              0x110
#define VCOM_RX_EPSIZE            0x40
#define VCOM_RX_BUFLEN            (VCOM_RX_EPSIZE*3)

#define CONTROL_LINE_DTR       (0x01)
#define CONTROL_LINE_RTS       (0x02)

voidFuncPtrUsb userUsbInterrupt = NULL;

/* persistent usb structs */

uint32 usbSendBytes(const uint8* sendBuf, uint32 nCount) {

	/*
	 * [ROBOTIS CHANGE][START]2012-12-14 fix some problems in transferring data to PC
	 * we change the usbSendBytes() because it generates some blocking issues.
	 * if length is above 64 bytes, every 64byte is sent to PC and the rest is also sent in else case{}
	 * */

	USB_TxDBytes(sendBuf, nCount);
	
	return nCount;


#if 0
  /* Last transmission hasn't finished, abort */
  if (countTx) {
    return 0;
  }

  // We can only put VCOM_TX_EPSIZE bytes in the buffer
  if (len > VCOM_TX_EPSIZE / 2) {
    len = VCOM_TX_EPSIZE / 2;
  }

  // Try to load some bytes if we can
  if (len) {
    UserToPMABufferCopy(sendBuf, VCOM_TX_ADDR, len);
    _SetEPTxCount(VCOM_TX_ENDP, len);
    countTx += len;
    _SetEPTxValid(VCOM_TX_ENDP);
  }

  return len;
#endif
//[ROBOTIS CHANGE][END]2012-12-14 fix some problems in transferring data to PC

}

/* returns the number of available bytes are in the recv FIFO */
uint32 usbBytesAvailable(void) {
	return USB_Rx_Cnt;
	//return newBytes;
}

/* copies len bytes from the local recieve FIFO (not
   usb packet buffer) into recvBuf and deq's the fifo.
   will only copy the minimum of len or the available
   bytes. returns the number of bytes copied */
uint32 usbReceiveBytes(uint8* recvBuf, uint32 len) {
  static int offset = 0;

  // [ROBOTIS] change all newBytes into USB_Rx_Cnt 20160102

  if (len > USB_Rx_Cnt) {
      len = USB_Rx_Cnt;
  }

  int i;
  for (i=0;i<len;i++) {
      //recvBuf[i] = (uint8)(usbRxDataBuffer[i+offset]);
      recvBuf[i] = (uint8)(USB_Rx_Buffer[i+offset]);
  }

  USB_Rx_Cnt -= len;
  offset += len;

  /* re-enable the rx endpoint which we had set to receive 0 bytes */
  if (USB_Rx_Cnt == 0) {
    SetEPRxCount(VCOM_RX_ENDP,VCOM_RX_EPSIZE);
    SetEPRxStatus(VCOM_RX_ENDP,EP_RX_VALID);
    offset = 0;
  }

  return len;
}

uint8 usbGetDTR() {
  return ((line_dtr_rts & CONTROL_LINE_DTR) != 0);
}

uint8 usbGetRTS() {
  return ((line_dtr_rts & CONTROL_LINE_RTS) != 0);
}

uint8 usbIsConfigured() {
  return (bDeviceState == CONFIGURED);
}

uint8 usbIsConnected() {
  return (bDeviceState != UNCONNECTED);
}

uint16 usbGetPending() {
  return countTx;
}

/**
 * [ROBOTIS][START] 2012-12-14 To support user interrupt
  */
void usb_attach_interrupt(voidFuncPtrUsb handler){

	userUsbInterrupt = handler;
}

void usb_detach_interrupt(void){

	userUsbInterrupt = NULL;
}
/**
 * [ROBOTIS][END] 2012-12-14 To support user interrupt
  */

void USB_Configuration(void)
{
	Set_USBClock();
	USB_Interrupts_Config();
	Set_System();
	USB_Init();
}
