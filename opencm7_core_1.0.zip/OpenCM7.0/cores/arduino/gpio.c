/******************************************************************************
* The MIT License
*
* Copyright (c) 2010 Perry Hung.
*
* Permission is hereby granted, free of charge, to any person
* obtaining a copy of this software and associated documentation
* files (the "Software"), to deal in the Software without
* restriction, including without limitation the rights to use, copy,
* modify, merge, publish, distribute, sublicense, and/or sell copies
* of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be
* included in all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
* BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
* ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
* CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*****************************************************************************/

/**
* @brief GPIO initialization routine
*/

#include "gpio.h"
////#include "rcc.h"

/*
* GPIO devices
*/

gpio_dev gpioa = {
	.regs      = GPIOA_BASE,
	.clk_id    = RCC_GPIOA,
	.exti_port = AFIO_EXTI_PA,
};
/** GPIO port A device. */
gpio_dev* const GPIOA_DEV = &gpioa;

gpio_dev gpiob = {
	.regs      = GPIOB_BASE,
	.clk_id    = RCC_GPIOB,
	.exti_port = AFIO_EXTI_PB,
};
/** GPIO port B device. */
gpio_dev* const GPIOB_DEV = &gpiob;

gpio_dev gpioc = {
	.regs      = GPIOC_BASE,
	.clk_id    = RCC_GPIOC,
	.exti_port = AFIO_EXTI_PC,
};
/** GPIO port C device. */
gpio_dev* const GPIOC_DEV = &gpioc;

/*
* GPIO convenience routines
*/

/**
* Initialize a GPIO device.
*
* Enables the clock for and resets the given device.
*
* @param dev GPIO device to initialize.
*/
void gpio_init(gpio_dev *dev) {
	rcc_clk_enable(dev->clk_id);
	rcc_reset_dev(dev->clk_id);
}
//
///**
//* Initialize and reset all available GPIO devices.
//*/
void gpio_init_all(void) {
	gpio_init(GPIOA_DEV);
	gpio_init(GPIOB_DEV);
	gpio_init(GPIOC_DEV);
#ifdef STM32_HIGH_DENSITY
	gpio_init(GPIOD);
	gpio_init(GPIOE);
	gpio_init(GPIOF);
	gpio_init(GPIOG);
#endif
}

/**
* Set the mode of a GPIO pin.
*
* @param dev GPIO device.
* @param pin Pin on the device whose mode to set, 0--15.
* @param mode General purpose or alternate function mode to set the pin to.
* @see gpio_pin_mode
*/

void gpio_set_mode(gpio_dev *dev, uint8 pin, gpio_pin_mode mode) {
	gpio_reg_map *regs = dev->regs;
	regs->MODER  &= ~(GPIO_MODER_MODER0 << (pin * 2));

	uint32 GPIOMode = 0;

	if(mode == GPIO_INPUT_FLOATING || mode == GPIO_INPUT_PD || mode == GPIO_INPUT_PU)
		GPIOMode = GPIO_Mode_IN;
	else if(mode == GPIO_OUTPUT_PP || mode == GPIO_OUTPUT_OD)
		GPIOMode = GPIO_Mode_OUT;
	else if(mode == GPIO_AF_OUTPUT_PP || mode == GPIO_AF_OUTPUT_OD)
		GPIOMode = GPIO_Mode_AF;
	else if(mode == GPIO_INPUT_ANALOG)
		GPIOMode = GPIO_Mode_AN;

	uint32 GPIOPuPd = 0;
	if(mode == GPIO_INPUT_PU)
		GPIOPuPd = GPIO_PuPd_UP;
	else if(mode == GPIO_INPUT_PD)
		GPIOPuPd = GPIO_PuPd_DOWN;

	regs->MODER |= (GPIOMode << (pin * 2));

	if ((GPIOMode == GPIO_Mode_OUT) || (GPIOMode == GPIO_Mode_AF))
	{
		uint32 GPIOOType = 0;

		if(mode == GPIO_OUTPUT_PP || mode == GPIO_AF_OUTPUT_PP)
			GPIOOType = GPIO_OType_PP;
		else if(mode == GPIO_OUTPUT_OD || mode == GPIO_AF_OUTPUT_OD)
			GPIOOType = GPIO_OType_OD;

		/* Check Speed mode parameters */
		//assert_param(IS_GPIO_SPEED(GPIO_InitStruct->GPIO_Speed));

		/* Speed mode configuration */
		regs->OSPEEDR &= ~(GPIO_OSPEEDER_OSPEEDR0 << (pin * 2));
		regs->OSPEEDR |= (GPIO_Speed_40MHz << (pin * 2));

		/*Check Output mode parameters */
		//assert_param(IS_GPIO_OTYPE(GPIO_InitStruct->GPIO_OType));

		/* Output mode configuration */
		regs->OTYPER  &= ~((GPIO_OTYPER_OT_0) << ((uint16)pin)) ;
		regs->OTYPER |= (uint16)(GPIOOType << ((uint16)pin));
	}

	/* Pull-up Pull down resistor configuration */
	regs->PUPDR &= ~(GPIO_PUPDR_PUPDR0 << ((uint16)pin * 2));
	regs->PUPDR |= (GPIOPuPd << (pin * 2));
}

void gpio_pin_af_config(gpio_dev *dev, uint8 pin, uint8 gpio_af)
{
	uint32 temp = 0x00;
	uint32 temp_2 = 0x00;

	temp = ((uint32)(gpio_af) << ((uint32)((uint32)pin & (uint32)0x07) * 4)) ;
	dev->regs->AFR[pin >> 0x03] &= ~((uint32)0xF << ((uint32)((uint32)pin & (uint32)0x07) * 4)) ;
	temp_2 = dev->regs->AFR[pin >> 0x03] | temp;
	dev->regs->AFR[pin >> 0x03] = temp_2;
}

/*
* SYSCFG
*/

/**
* @brief Selects the GPIO pin used as EXTI Line.
*/
// [ROBOTIS] SYSCFG exists in STM32L 20151228

void SYSCFG_EXTILineConfig(uint8 EXTI_PortSourceGPIOx, uint8 EXTI_PinSourcex)
{
  uint32 tmp = 0x00;

  tmp = ((uint32)0x0F) << (0x04 * (EXTI_PinSourcex & (uint8)0x03));
  SYSCFG_BASE->EXTICR[EXTI_PinSourcex >> 0x02] &= ~tmp;
  SYSCFG_BASE->EXTICR[EXTI_PinSourcex >> 0x02] |= (((uint32)EXTI_PortSourceGPIOx) << (0x04 * (EXTI_PinSourcex & (uint8)0x03)));
}


















/*
* AFIO
*/

/**
* @brief Initialize the AFIO clock, and reset the AFIO registers.
*/
// [ROBOTIS] no afio in STM32L 20151128
//void afio_init(void) {
//	rcc_clk_enable(RCC_AFIO);
//	rcc_reset_dev(RCC_AFIO);
//}

//#define AFIO_EXTI_SEL_MASK 0xF

/**
* @brief Select a source input for an external interrupt.
*
* @param exti      External interrupt.
* @param gpio_port Port which contains pin to use as source input.
* @see afio_exti_num
* @see afio_exti_port
*/
//void afio_exti_select(afio_exti_num exti, afio_exti_port gpio_port) {
//	__io uint32 *exti_cr = &AFIO_BASE->EXTICR1 + exti / 4;
//	uint32 shift = 4 * (exti % 4);
//	uint32 cr = *exti_cr;
//
//	cr &= ~(AFIO_EXTI_SEL_MASK << shift);
//	cr |= gpio_port << shift;
//	*exti_cr = cr;
//}

/**
* @brief Perform an alternate function remap.
* @param remapping Remapping to perform.
*/
//void afio_remap(afio_remap_peripheral remapping) {
//	if (remapping & AFIO_REMAP_USE_MAPR2) {
//		remapping &= ~AFIO_REMAP_USE_MAPR2;
//		AFIO_BASE->MAPR2 |= remapping;
//	} else {
//		AFIO_BASE->MAPR |= remapping;
//	}
//}
