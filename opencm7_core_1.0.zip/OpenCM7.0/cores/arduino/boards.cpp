/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 Perry Hung.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

/** BOARD_USART2_RX_PIN
 * @brief Generic board initialization routines.
 *
 * By default, we bring up all Maple boards to 72MHz, clocked off the
 * PLL, driven by the 8MHz external crystal. AHB and APB2 are clocked
 * at 72MHz.  APB1 is clocked at 36MHz.
 */

#include "boards.h"

#include "rcc.h"
#include "nvic.h"
#include "systick.h"
#include "gpio.h"
#include "adc.h"
#include "timer.h"
#include "usb.h"

//for debug
#include "usart.h"
#include "Arduino-compatibles.h"

static void setupUSB(void);
static void setupFlash(void);
static void setupClocks(void);
static void setupNVIC(void);
static void setupADC(void);
static void setupTimers(void);
static void setupMotors(void);
void isrMotors(void);

void init(void) {
	setupUSB();

    setupClocks();
    setupNVIC();
    systick_init(SYSTICK_RELOAD_VAL);

    exti_switch_init();
    setupADC();
    setupTimers();
    boardInit();

#ifdef CM9_DEBUG
    //for debug
    gpio_set_mode(GPIOA_DEV, 2, GPIO_AF_OUTPUT_PP);
 	gpio_set_mode(GPIOA_DEV, 3, GPIO_INPUT_FLOATING);
 	usart_init(USART2_DEV);
 	usart_set_baud_rate(USART2_DEV, STM32_PCLK1, 57600);
 	usart_enable(USART2_DEV);
#endif

}
#if 0
/* You could farm this out to the files in boards/ if e.g. it takes
 * too long to test on Maple Native (all those FSMC pins...). */
bool boardUsesPin(uint8 pin) {
    for (int i = 0; i < BOARD_NR_USED_PINS; i++) {
        if (pin == boardUsedPins[i]) {
            return true;
        }
    }
    return false;
}
#endif

static void setupFlash(void) {

}

static void setupUSB()
{
	USB_Configuration();
}

/*
 * Clock setup.  Note that some of this only takes effect if we're
 * running bare metal and the bootloader hasn't done it for us
 * already.
 *
 * If you change this function, you MUST change the file-level Doxygen
 * comment above.
 */
static void setupClocks() {
	rcc_clk_init();
}

static void setupNVIC() {

}

static void adcDefaultConfig(const adc_dev* dev);

static void setupADC() {
    adc_foreach(adcDefaultConfig);
}

static void timerDefaultConfig(timer_dev*);

static void setupTimers() {
    timer_foreach(timerDefaultConfig);
}

#define		PWM_RESOLUTION		  0x3F

#define		OLLO_PORT_FIRST		  1
#define     SERVO_PORT_FIRST	  3
#define		SERVO_PORT_LAST		  6

volatile uint8 gbMotorPwmArray[SERVO_PORT_LAST + 1] = {0,0,0,0,0,0,0};
volatile uint8 gbMotorPwmDir[SERVO_PORT_LAST + 1] = {0,0,0,0,0,0,0};
volatile uint8 gbTorqueEnable[SERVO_PORT_LAST + 1] = {0,0,0,0,0,0,0};
volatile uint8 gbMaxTorque[SERVO_PORT_LAST + 1] = {0,0,0,0,0,0,0};
volatile uint16 gwGoalPosition[SERVO_PORT_LAST + 1];
volatile uint16 gwADCValue[SERVO_PORT_LAST + 1];
volatile bool gbMotorStart = false;

static void setupMotors() {
    Timer11.pause();
    Timer11.setPeriod(120);
    Timer11.setMode(TIMER_CH1, TIMER_OUTPUT_COMPARE);
    Timer11.setCompare(TIMER_CH1, 1);
    //Timer11.attachInterrupt(TIMER_CH1, isrMotors);
    Timer11.refresh();
    Timer11.resume();

    gpio_set_mode(GPIOB_DEV, 6, GPIO_OUTPUT_PP);
    gpio_set_mode(GPIOB_DEV, 7, GPIO_OUTPUT_PP);

    gpio_set_mode(GPIOB_DEV, 0, GPIO_OUTPUT_PP);
    gpio_set_mode(GPIOB_DEV, 1, GPIO_OUTPUT_PP);
}

void isrMotors(void)
{
	if(gbMotorStart == true)
	{
		static uint8 bMotorPwmCounter=0;
		static uint8 bMotorControlCounter=0;
		byte bCount;
		bMotorPwmCounter = ((++bMotorPwmCounter) & PWM_RESOLUTION);
		bMotorControlCounter++;

		for( bCount = SERVO_PORT_FIRST; bCount <= SERVO_PORT_LAST ; bCount++ )
		{
			if( bMotorPwmCounter < gbMotorPwmArray[bCount] )
			{
				if( gbMotorPwmDir[bCount] )
				{
					switch(bCount)
					{
					case 3:
						//MOTOR_CCW_3		//CCW
						gpio_write_bit(GPIOB_DEV,2,0);
						gpio_write_bit(GPIOB_DEV,10,1);
						break;
					case 4:
						//MOTOR_CCW_4		//CCW
						gpio_write_bit(GPIOB_DEV,11,0);
						gpio_write_bit(GPIOB_DEV,12,1);
						break;
					case 5:
						//MOTOR_CCW_5		//CCW
						gpio_write_bit(GPIOB_DEV,13,0);
						gpio_write_bit(GPIOB_DEV,14,1);
						break;
					case 6:
						//MOTOR_CCW_6		//CCW
						gpio_write_bit(GPIOB_DEV,15,0);
						gpio_write_bit(GPIOA_DEV,8,1);
						break;
					}
				}
				else
				{
					switch(bCount)
					{
					case 3:
						//MOTOR_CW_3		//CW
						gpio_write_bit(GPIOB_DEV,2,1);
						gpio_write_bit(GPIOB_DEV,10,0);
						break;
					case 4:
						//MOTOR_CW_4		//CW
						gpio_write_bit(GPIOB_DEV,11,1);
						gpio_write_bit(GPIOB_DEV,12,0);
						break;
					case 5:
						//MOTOR_CW_5		//CW
						gpio_write_bit(GPIOB_DEV,13,1);
						gpio_write_bit(GPIOB_DEV,14,0);
						break;
					case 6:
						//MOTOR_CW_6		//CW
						gpio_write_bit(GPIOB_DEV,15,1);
						gpio_write_bit(GPIOA_DEV,8,0);
						break;
					}
				}
			}
			else
			{
				switch(bCount)
				{
				case 3:
					//MOTOR_ON_3
					gpio_write_bit(GPIOB_DEV,2,1);
					gpio_write_bit(GPIOB_DEV,10,1);
					break;
				case 4:
					//MOTOR_ON_4
					gpio_write_bit(GPIOB_DEV,11,1);
					gpio_write_bit(GPIOB_DEV,12,1);
					break;
				case 5:
					//MOTOR_ON_5
					gpio_write_bit(GPIOB_DEV,13,1);
					gpio_write_bit(GPIOB_DEV,14,1);
					break;
				case 6:
					//MOTOR_ON_6
					gpio_write_bit(GPIOB_DEV,15,1);
					gpio_write_bit(GPIOA_DEV,8,1);
					break;
				}
			}
		}

		if( bMotorPwmCounter < gbMotorPwmArray[OLLO_PORT_FIRST])
		{
			if( gbMotorPwmDir[OLLO_PORT_FIRST] )
			{   //MOTOR_CCW_1		//CCW
				gpio_write_bit(GPIOB_DEV,6,0);
				gpio_write_bit(GPIOB_DEV,7,1);
			}
			else
			{   //MOTOR_CW_1		//CW
				gpio_write_bit(GPIOB_DEV,6,1);
				gpio_write_bit(GPIOB_DEV,7,0);
			}
		}
		else
		{    //MOTOR_ON_1 // 20130304
			gpio_write_bit(GPIOB_DEV,6,1);
			gpio_write_bit(GPIOB_DEV,7,1);
		}

		if( bMotorPwmCounter < gbMotorPwmArray[OLLO_PORT_FIRST + 1])
		{
			if( gbMotorPwmDir[OLLO_PORT_FIRST + 1] )
			{   //MOTOR_CCW_1		//CCW
				gpio_write_bit(GPIOB_DEV,0,0);
				gpio_write_bit(GPIOB_DEV,1,1);
			}
			else
			{   //MOTOR_CW_1		//CW
				gpio_write_bit(GPIOB_DEV,0,1);
				gpio_write_bit(GPIOB_DEV,1,0);
			}
		}
		else
		{    //MOTOR_ON_1
			gpio_write_bit(GPIOB_DEV,0,1);
			gpio_write_bit(GPIOB_DEV,1,1);
		}

		if(bMotorControlCounter == 0x80)
		{
			bMotorControlCounter = 0;
			for( bCount = SERVO_PORT_FIRST ; bCount <= SERVO_PORT_LAST; bCount++)
			{
				if( gbTorqueEnable[bCount])
				{
					int nDiff, nPDgain;
					uint16 wMaxTq;
					uint8 bMotorPwmDir;
					switch(bCount)
					{
					case 3:
						gwADCValue[bCount] = analogRead(5);
						break;
					case 4:
						gwADCValue[bCount] = analogRead(0);
						break;
					case 5:
						gwADCValue[bCount] = analogRead(1);
						break;
					case 6:
						gwADCValue[bCount] = analogRead(6);
						break;
					}

					nDiff = (int)( gwGoalPosition[bCount] - (gwADCValue[bCount] / 4));
					nPDgain = nDiff * 8;
					if( nPDgain < 0 )
					{
						bMotorPwmDir = 1;
						nPDgain = -nPDgain;
					}
					else bMotorPwmDir = 0;
					nPDgain >>= 4;

					wMaxTq = gbMaxTorque[bCount];
					if( nPDgain > wMaxTq )		gbMotorPwmArray[bCount] = (byte)wMaxTq;
					else						gbMotorPwmArray[bCount] = (byte)nPDgain;

					if( bMotorPwmDir )gbMotorPwmDir[bCount] = 1;
					else gbMotorPwmDir[bCount] = 0;
				}
			}

		}
	}
}

// index : 1 ~ 6
void setMotorSpeed(uint8 index, uint8 direction, uint16 speed)
{
	if(gbMotorStart == false)
	{
		Timer11.attachInterrupt(TIMER_CH1, isrMotors);
		gbMotorStart = true;
	}

	gbMotorPwmDir[index] = direction;
	gbMotorPwmArray[index] = (uint8)(speed / 16);
}

// index : 3 ~ 6
void setMotorPosition(uint8 index, uint16 position)
{
	gwGoalPosition[index] = position;
}

// index : 3 ~ 6
void setMotorMode(uint8 index, uint8 mode)
{
	gbTorqueEnable[index] = mode;
	if(mode == 1)
	{
		switch(index)
		{
		case 3:
			gwGoalPosition[index] = analogRead(5)/4;
			break;
		case 4:
			gwGoalPosition[index] = analogRead(0)/4;
			break;
		case 5:
			gwGoalPosition[index] = analogRead(1)/4;
			break;
		case 6:
			gwGoalPosition[index] = analogRead(6)/4;
			break;
		}
		gbMaxTorque[index] = 57;
	}
	else
		gbMotorPwmArray[index] = 0;
}

void exti_switch_init(void)
{
	exti_attach_interrupt(AFIO_EXTI_5, AFIO_EXTI_PB, power_switch_off, EXTI_FALLING);
	gpio_set_mode(GPIOC_DEV, 13, GPIO_OUTPUT_PP);
}

void power_switch_off(void)
{
	gpio_write_bit(GPIOA_DEV, 13, 1);

	// [ROBOTIS] STOP ALL MOTORS 20160109
	gpio_write_bit(GPIOB_DEV, 0, 0);
	gpio_write_bit(GPIOB_DEV, 1, 0);
	gpio_write_bit(GPIOB_DEV, 6, 0);
	gpio_write_bit(GPIOB_DEV, 7, 0);
	gpio_write_bit(GPIOB_DEV,2,0);
	gpio_write_bit(GPIOB_DEV,10,0);
	gpio_write_bit(GPIOB_DEV,11,0);
	gpio_write_bit(GPIOB_DEV,12,0);
	gpio_write_bit(GPIOB_DEV,13,0);
	gpio_write_bit(GPIOB_DEV,14,0);
	gpio_write_bit(GPIOB_DEV,15,0);
	gpio_write_bit(GPIOA_DEV,8,0);

	// disable buzzer
	Timer4.pause();
	pinMode(13, INPUT);

	// turn off GREEN, BLUE LED
	gpio_write_bit(GPIOA_DEV, 14, 1);
	gpio_write_bit(GPIOA_DEV, 15, 1);

	// RED LED blink twice
	delay(200);
	gpio_write_bit(GPIOA_DEV, 13, 0);
	delay(200);
	gpio_write_bit(GPIOA_DEV, 13, 1);
	delay(200);
	gpio_write_bit(GPIOA_DEV, 13, 0);
	delay(200);

	gpio_write_bit(GPIOA_DEV, 13, 1);
	gpio_write_bit(GPIOC_DEV, 13, 1);

	gpio_write_bit(GPIOB_DEV, 9, 0);
	while(1);
}

static void adcDefaultConfig(const adc_dev *dev) {
    //adc_init(dev);

	((rcc_reg_map *)0x40023800)->APB2ENR |= RCC_APB2LPENR_ADC1LPEN;

    adc_configuration(dev);
}

static void timerDefaultConfig(timer_dev *dev) {
	timer_gen_reg_map *regs = (dev->regs).gen;  // [ROBOTIS] 20151201
    
    const uint16 full_overflow = 0xFFFF;
    const uint16 half_duty = 0x8FFF;

    timer_init(dev);
    timer_pause(dev);

    regs->CR1 = TIMER_CR1_ARPE;
    regs->PSC = 1;
    regs->SR = 0;
    regs->DIER = 0;
    regs->EGR = TIMER_EGR_UG;

    switch (dev->type) {
        // fall-through
    case TIMER_GENERAL:
        timer_set_reload(dev, full_overflow);

        for (int channel = 1; channel <= 4; channel++) {
            timer_set_compare(dev, channel, half_duty);
            timer_oc_set_mode(dev, channel, TIMER_OC_MODE_PWM_1, TIMER_OC_PE);
        }
        // fall-through
    case TIMER_BASIC:
        break;
    }

    timer_resume(dev);
}
