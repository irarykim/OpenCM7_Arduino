/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 Perry Hung.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
*****************************************************************************/

/**
 *  @file gpio.h
 *
 *  @brief General purpose I/O (GPIO) and Alternate Function I/O
 *         (AFIO) prototypes, defines, and inlined access functions.
 */

#ifndef _GPIO_H_
#define _GPIO_H_

#include "stm32.h"
#include "util.h"
#include "rcc.h"


#ifdef __cplusplus
extern "C"{
#endif

/*
 * GPIO register maps and devices
 */

/** GPIO register map type */

typedef struct gpio_reg_map {
  __io uint32 MODER;        /*!< GPIO port mode register,                     Address offset: 0x00      */
  __io uint16 OTYPER;       /*!< GPIO port output type register,              Address offset: 0x04      */
  uint16 RESERVED0;         /*!< Reserved,                                    0x06                      */
  __io uint32 OSPEEDR;      /*!< GPIO port output speed register,             Address offset: 0x08      */
  __io uint32 PUPDR;        /*!< GPIO port pull-up/pull-down register,        Address offset: 0x0C      */
  __io uint16 IDR;          /*!< GPIO port input data register,               Address offset: 0x10      */
  uint16 RESERVED1;         /*!< Reserved,                                    0x12                      */
  __io uint16 ODR;          /*!< GPIO port output data register,              Address offset: 0x14      */
  uint16 RESERVED2;         /*!< Reserved,                                    0x16                      */
  __io uint16 BSRRL;        /*!< GPIO port bit set/reset low registerBSRR,    Address offset: 0x18      */
  __io uint16 BSRRH;        /*!< GPIO port bit set/reset high registerBSRR,   Address offset: 0x1A      */
  __io uint32 LCKR;         /*!< GPIO port configuration lock register,       Address offset: 0x1C      */
  __io uint32 AFR[2];       /*!< GPIO alternate function low register,        Address offset: 0x20-0x24 */
  __io uint16 BRR;          /*!< GPIO bit reset register,                     Address offset: 0x28      */
  uint16 RESERVED3;         /*!< Reserved,                                    0x2A                      */
} gpio_reg_map;
/**
 * @brief External interrupt line port selector.
 *
 * Used to determine which GPIO port to map an external interrupt line
 * onto. */
/* (See AFIO sections, below) */
typedef enum afio_exti_port {
    AFIO_EXTI_PA,               /**< Use port A (PAx) pin. */
    AFIO_EXTI_PB,               /**< Use port B (PBx) pin. */
    AFIO_EXTI_PC,               /**< Use port C (PCx) pin. */
    AFIO_EXTI_PD,               /**< Use port D (PDx) pin. */
#ifdef STM32_HIGH_DENSITY
    AFIO_EXTI_PE,               /**< Use port E (PEx) pin. */
    AFIO_EXTI_PF,               /**< Use port F (PFx) pin. */
    AFIO_EXTI_PG,               /**< Use port G (PGx) pin. */
#endif
} afio_exti_port;

/** GPIO device type */
typedef struct gpio_dev {
    gpio_reg_map *regs;       /**< Register map */
    rcc_clk_id clk_id;        /**< RCC clock information */
    afio_exti_port exti_port; /**< AFIO external interrupt port value */
} gpio_dev;

extern gpio_dev gpioa;
extern gpio_dev* const GPIOA_DEV;
extern gpio_dev gpiob;
extern gpio_dev* const GPIOB_DEV;
extern gpio_dev gpioc;
extern gpio_dev* const GPIOC_DEV;
extern gpio_dev gpiod;
extern gpio_dev* const GPIOD_DEV;
#ifdef STM32_HIGH_DENSITY
extern gpio_dev gpioe;
extern gpio_dev* const GPIOE;
extern gpio_dev gpiof;
extern gpio_dev* const GPIOF;
extern gpio_dev gpiog;
extern gpio_dev* const GPIOG;
#endif

/** GPIO port A register map base pointer */
#define GPIOA_BASE                      ((struct gpio_reg_map*)0x40020000)
/** GPIO port B register map base pointer */
#define GPIOB_BASE                      ((struct gpio_reg_map*)0x40020400)
/** GPIO port C register map base pointer */
#define GPIOC_BASE                      ((struct gpio_reg_map*)0x40020800)
/** GPIO port D register map base pointer */
#define GPIOD_BASE                      ((struct gpio_reg_map*)0x40020C00)
#ifdef STM32_HIGH_DENSITY
/** GPIO port E register map base pointer */
#define GPIOE_BASE                      ((struct gpio_reg_map*)0x40021000)
/** GPIO port F register map base pointer */
#define GPIOF_BASE                      ((struct gpio_reg_map*)0x40021400)
/** GPIO port G register map base pointer */
#define GPIOG_BASE                      ((struct gpio_reg_map*)0x40021800)
#endif

/*
 * GPIO register bit definitions
 */

/* Control registers, low and high */

#define GPIO_CR_CNF                     (0x3 << 2)
#define GPIO_CR_CNF_INPUT_ANALOG        (0x0 << 2)
#define GPIO_CR_CNF_INPUT_FLOATING      (0x1 << 2)
#define GPIO_CR_CNF_INPUT_PU_PD         (0x2 << 2)
#define GPIO_CR_CNF_OUTPUT_PP           (0x0 << 2)
#define GPIO_CR_CNF_OUTPUT_OD           (0x1 << 2)
#define GPIO_CR_CNF_AF_OUTPUT_PP        (0x2 << 2)
#define GPIO_CR_CNF_AF_OUTPUT_OD        (0x3 << 2)
#define GPIO_CR_MODE                    0x3
#define GPIO_CR_MODE_INPUT              0x0
#define GPIO_CR_MODE_OUTPUT_10MHZ       0x1
#define GPIO_CR_MODE_OUTPUT_2MHZ        0x2
#define GPIO_CR_MODE_OUTPUT_50MHZ       0x3

#define GPIO_MODER_MODER0          ((uint32)0x00000003)
#define GPIO_OSPEEDER_OSPEEDR0     ((uint32)0x00000003)
#define GPIO_OTYPER_OT_0           ((uint32)0x00000001)
#define GPIO_PUPDR_PUPDR0          ((uint32)0x00000003)

/** @defgroup GPIO_Alternat_function_selection_define
  * @{
  */

/**
  * @brief  AF 0 selection
  */
#define GPIO_AF_RTC_50Hz      ((uint8)0x00)  /*!< RTC 50/60 Hz Alternate Function mapping */
#define GPIO_AF_MCO           ((uint8)0x00)  /*!< MCO Alternate Function mapping */
#define GPIO_AF_RTC_AF1       ((uint8)0x00)  /*!< RTC_AF1 Alternate Function mapping */
#define GPIO_AF_WKUP          ((uint8)0x00)  /*!< Wakeup (WKUP1, WKUP2 and WKUP3) Alternate Function mapping */
#define GPIO_AF_SWJ           ((uint8)0x00)  /*!< SWJ (SW and JTAG) Alternate Function mapping */
#define GPIO_AF_TRACE         ((uint8)0x00)  /*!< TRACE Alternate Function mapping */

/**
  * @brief  AF 1 selection
  */
#define GPIO_AF_TIM2          ((uint8)0x01)  /*!< TIM2 Alternate Function mapping */
/**
  * @brief  AF 2 selection
  */
#define GPIO_AF_TIM3          ((uint8)0x02)  /*!< TIM3 Alternate Function mapping */
#define GPIO_AF_TIM4          ((uint8)0x02)  /*!< TIM4 Alternate Function mapping */
#define GPIO_AF_TIM5          ((uint8)0x02)  /*!< TIM5 Alternate Function mapping */
/**
  * @brief  AF 3 selection
  */
#define GPIO_AF_TIM9           ((uint8)0x03)  /*!< TIM9 Alternate Function mapping */
#define GPIO_AF_TIM10          ((uint8)0x03)  /*!< TIM10 Alternate Function mapping */
#define GPIO_AF_TIM11          ((uint8)0x03)  /*!< TIM11 Alternate Function mapping */
/**
  * @brief  AF 4 selection
  */
#define GPIO_AF_I2C1          ((uint8)0x04)  /*!< I2C1 Alternate Function mapping */
#define GPIO_AF_I2C2          ((uint8)0x04)  /*!< I2C2 Alternate Function mapping */
/**
  * @brief  AF 5 selection
  */
#define GPIO_AF_SPI1          ((uint8)0x05)  /*!< SPI1 Alternate Function mapping */
#define GPIO_AF_SPI2          ((uint8)0x05)  /*!< SPI2 Alternate Function mapping */
/**
  * @brief  AF 6 selection
  */
#define GPIO_AF_SPI3          ((uint8)0x06)  /*!< SPI3 Alternate Function mapping */
/**
  * @brief  AF 7 selection
  */
#define GPIO_AF_USART1        ((uint8)0x07)  /*!< USART1 Alternate Function mapping */
#define GPIO_AF_USART2        ((uint8)0x07)  /*!< USART2 Alternate Function mapping */
#define GPIO_AF_USART3        ((uint8)0x07)  /*!< USART3 Alternate Function mapping */
/**
  * @brief  AF 8 selection
  */
#define GPIO_AF_UART4         ((uint8)0x08)  /*!< UART4 Alternate Function mapping */
#define GPIO_AF_UART5         ((uint8)0x08)  /*!< UART5 Alternate Function mapping */
/**
  * @brief  AF 10 selection
  */
#define GPIO_AF_USB           ((uint8)0xA)  /*!< USB Full speed device  Alternate Function mapping */
/**
  * @brief  AF 11 selection
  */
#define GPIO_AF_LCD           ((uint8)0x0B)  /*!< LCD Alternate Function mapping */
/**
  * @brief  AF 12 selection
  */
#define GPIO_AF_FSMC           ((uint8)0x0C)  /*!< FSMC Alternate Function mapping */
#define GPIO_AF_SDIO           ((uint8)0x0C)  /*!< SDIO Alternate Function mapping */
/**
  * @brief  AF 14 selection
  */
#define GPIO_AF_RI            ((uint8)0x0E)  /*!< RI Alternate Function mapping */

/**
  * @brief  AF 15 selection
  */
#define GPIO_AF_EVENTOUT      ((uint8)0x0F)  /*!< EVENTOUT Alternate Function mapping */

#define IS_GPIO_AF(AF)   (((AF) == GPIO_AF_RTC_50Hz) || ((AF) == GPIO_AF_MCO)    || \
                          ((AF) == GPIO_AF_RTC_AF1)  || ((AF) == GPIO_AF_WKUP)   || \
                          ((AF) == GPIO_AF_SWJ)      || ((AF) == GPIO_AF_TRACE)  || \
                          ((AF) == GPIO_AF_TIM2)     || ((AF)== GPIO_AF_TIM3)    || \
                          ((AF) == GPIO_AF_TIM4)     || ((AF)== GPIO_AF_TIM9)    || \
                          ((AF) == GPIO_AF_TIM10)    || ((AF)== GPIO_AF_TIM11)   || \
                          ((AF) == GPIO_AF_I2C1)     || ((AF) == GPIO_AF_I2C2)   || \
                          ((AF) == GPIO_AF_SPI1)     || ((AF) == GPIO_AF_SPI2)   || \
                          ((AF) == GPIO_AF_USART1)   || ((AF) == GPIO_AF_USART2) || \
                          ((AF) == GPIO_AF_USART3)   || ((AF) == GPIO_AF_USB)    || \
                          ((AF) == GPIO_AF_LCD)      || ((AF) == GPIO_AF_RI)     || \
                          ((AF) == GPIO_AF_TIM5)     || ((AF) == GPIO_AF_SPI3)   || \
                          ((AF) == GPIO_AF_UART4)    || ((AF) == GPIO_AF_UART5)  || \
                          ((AF) == GPIO_AF_FSMC)     || ((AF) == GPIO_AF_SDIO)   || \
                          ((AF) == GPIO_AF_EVENTOUT))

/**
  * @}
  */

/**
 * @brief GPIO Pin modes.
 *
 * These only allow for 50MHZ max output speeds; if you want slower,
 * use direct register access.
 */
typedef enum gpio_pin_mode {
    GPIO_OUTPUT_PP = (GPIO_CR_CNF_OUTPUT_PP |
                      GPIO_CR_MODE_OUTPUT_50MHZ), /**< Output push-pull. */
    GPIO_OUTPUT_OD = (GPIO_CR_CNF_OUTPUT_OD |
                      GPIO_CR_MODE_OUTPUT_50MHZ), /**< Output open-drain. */
    GPIO_AF_OUTPUT_PP = (GPIO_CR_CNF_AF_OUTPUT_PP |
                         GPIO_CR_MODE_OUTPUT_50MHZ), /**< Alternate function
                                                        output push-pull. */
    GPIO_AF_OUTPUT_OD = (GPIO_CR_CNF_AF_OUTPUT_OD |
                         GPIO_CR_MODE_OUTPUT_50MHZ), /**< Alternate function
                                                        output open drain. */
    GPIO_INPUT_ANALOG = (GPIO_CR_CNF_INPUT_ANALOG |
                         GPIO_CR_MODE_INPUT), /**< Analog input. */
    GPIO_INPUT_FLOATING = (GPIO_CR_CNF_INPUT_FLOATING |
                           GPIO_CR_MODE_INPUT), /**< Input floating. */
    GPIO_INPUT_PD = (GPIO_CR_CNF_INPUT_PU_PD |
                     GPIO_CR_MODE_INPUT), /**< Input pull-down. */
    GPIO_INPUT_PU /**< Input pull-up. */
    /* GPIO_INPUT_PU treated as a special case, for ODR twiddling */
} gpio_pin_mode;

/** @defgroup Configuration_Mode_enumeration 
  * @{
  */ 
typedef enum
{ 
  GPIO_Mode_IN   = 0x00, /*!< GPIO Input Mode */
  GPIO_Mode_OUT  = 0x01, /*!< GPIO Output Mode */
  GPIO_Mode_AF   = 0x02, /*!< GPIO Alternate function Mode */
  GPIO_Mode_AN   = 0x03  /*!< GPIO Analog Mode */
}GPIOMode_TypeDef;

/** @defgroup Output_type_enumeration
  * @{
  */ 
typedef enum
{ GPIO_OType_PP = 0x00,
  GPIO_OType_OD = 0x01
}GPIOOType_TypeDef;

/** @defgroup Output_Maximum_frequency_enumeration 
  * @{
  */ 
typedef enum
{ 
  GPIO_Speed_400KHz = 0x00, /*!< Very Low Speed */
  GPIO_Speed_2MHz   = 0x01, /*!< Low Speed */
  GPIO_Speed_10MHz  = 0x02, /*!< Medium Speed */
  GPIO_Speed_40MHz  = 0x03  /*!< High Speed */
}GPIOSpeed_TypeDef;

/** @defgroup Configuration_Pull-Up_Pull-Down_enumeration 
  * @{
  */ 
typedef enum
{ GPIO_PuPd_NOPULL = 0x00,
  GPIO_PuPd_UP     = 0x01,
  GPIO_PuPd_DOWN   = 0x02
}GPIOPuPd_TypeDef;


/*
 * GPIO Convenience routines
 */

void gpio_init(gpio_dev *dev);
void gpio_init_all(void);
void gpio_set_mode(gpio_dev *dev, uint8 pin, gpio_pin_mode mode);
void gpio_pin_af_config(gpio_dev *dev, uint8 pin, uint8 gpio_af);

/**
 * @brief Get a GPIO port's corresponding afio_exti_port.
 * @param dev GPIO device whose afio_exti_port to return.
 */
static inline afio_exti_port gpio_exti_port(gpio_dev *dev) {
    return dev->exti_port;
}

/**
 * Set or reset a GPIO pin.
 *
 * Pin must have previously been configured to output mode.
 *
 * @param dev GPIO device whose pin to set.
 * @param pin Pin on to set or reset
 * @param val If true, set the pin.  If false, reset the pin.
 */
//static inline void gpio_write_bit(gpio_dev *dev, uint8 pin, uint8 val) {
//    if (val) {
//        dev->regs->BSRR = BIT(pin);
//    } else {
//        dev->regs->BRR = BIT(pin);
//    }
//}
static inline void gpio_write_bit(gpio_dev *dev, uint8 pin, uint8 val) {
    if (val) {
		dev->regs->BSRRL = BIT(pin);
    } else {
		dev->regs->BSRRH = BIT(pin);
    }
}
/**
 * Determine whether or not a GPIO pin is set.
 *
 * Pin must have previously been configured to input mode.
 *
 * @param dev GPIO device whose pin to test.
 * @param pin Pin on dev to test.
 * @return True if the pin is set, false otherwise.
 */
static inline uint32 gpio_read_bit(gpio_dev *dev, uint8 pin) {
    return dev->regs->IDR & BIT(pin);
}

/**
 * Toggle a pin configured as output push-pull.
 * @param dev GPIO device.
 * @param pin Pin on dev to toggle.
 */
static inline void gpio_toggle_bit(gpio_dev *dev, uint8 pin) {
    dev->regs->ODR = dev->regs->ODR ^ BIT(pin);
}

/*
 * SYSCFG register map
 */

// [ROBOTIS] SYSCFG exists in STM32L 20151228

typedef struct syscfg_reg_map
{
  __io uint32 MEMRMP;       /*!< SYSCFG memory remap register,                      Address offset: 0x00      */
  __io uint32 PMC;          /*!< SYSCFG peripheral mode configuration register,     Address offset: 0x04      */
  __io uint32 EXTICR[4];    /*!< SYSCFG external interrupt configuration registers, Address offset: 0x08-0x14 */
} syscfg_reg_map;

/** SYSCFG register map base pointer. */
#define SYSCFG_BASE                       ((struct syscfg_reg_map *)0x40010000)


/*
 * AFIO register map
 */

// [ROBOTIS] no afio in STM32L 20151128

/** AFIO register map */

///**
// * External interrupt line numbers.
// */
typedef enum afio_exti_num {
    AFIO_EXTI_0,                /**< External interrupt line 0. */
    AFIO_EXTI_1,                /**< External interrupt line 1. */
    AFIO_EXTI_2,                /**< External interrupt line 2. */
    AFIO_EXTI_3,                /**< External interrupt line 3. */
    AFIO_EXTI_4,                /**< External interrupt line 4. */
    AFIO_EXTI_5,                /**< External interrupt line 5. */
    AFIO_EXTI_6,                /**< External interrupt line 6. */
    AFIO_EXTI_7,                /**< External interrupt line 7. */
    AFIO_EXTI_8,                /**< External interrupt line 8. */
    AFIO_EXTI_9,                /**< External interrupt line 9. */
    AFIO_EXTI_10,               /**< External interrupt line 10. */
    AFIO_EXTI_11,               /**< External interrupt line 11. */
    AFIO_EXTI_12,               /**< External interrupt line 12. */
    AFIO_EXTI_13,               /**< External interrupt line 13. */
    AFIO_EXTI_14,               /**< External interrupt line 14. */
    AFIO_EXTI_15,               /**< External interrupt line 15. */
} afio_exti_num;

#ifdef __cplusplus
}
#endif

#endif

