/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 LeafLabs LLC.
 * libcs3_stm32_med_density.a
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

// Force init to be called *first*, i.e. before static object allocation.
// Otherwise, statically allocated objects that need libmaple may fail.

#include <Arduino.h>


 __attribute__(( constructor )) void premain() {
    init();
 }

typedef struct gpio_reg {
  __io uint32 MODER;        /*!< GPIO port mode register,                     Address offset: 0x00      */
  __io uint16 OTYPER;       /*!< GPIO port output type register,              Address offset: 0x04      */
  uint16 RESERVED0;         /*!< Reserved,                                    0x06                      */
  __io uint32 OSPEEDR;      /*!< GPIO port output speed register,             Address offset: 0x08      */
  __io uint32 PUPDR;        /*!< GPIO port pull-up/pull-down register,        Address offset: 0x0C      */
  __io uint16 IDR;          /*!< GPIO port input data register,               Address offset: 0x10      */
  uint16 RESERVED1;         /*!< Reserved,                                    0x12                      */
  __io uint16 ODR;          /*!< GPIO port output data register,              Address offset: 0x14      */
  uint16 RESERVED2;         /*!< Reserved,                                    0x16                      */
  __io uint16 BSRRL;        /*!< GPIO port bit set/reset low registerBSRR,    Address offset: 0x18      */
  __io uint16 BSRRH;        /*!< GPIO port bit set/reset high registerBSRR,   Address offset: 0x1A      */
  __io uint32 LCKR;         /*!< GPIO port configuration lock register,       Address offset: 0x1C      */
  __io uint32 AFR[2];       /*!< GPIO alternate function low register,        Address offset: 0x20-0x24 */
  __io uint16 BRR;          /*!< GPIO bit reset register,                     Address offset: 0x28      */
  uint16 RESERVED3;         /*!< Reserved,                                    0x2A                      */
} gpio_reg;
//
///** GPIO port A register map base pointer */
#define GPIOA_BASE_ADDR                      (0x40020000)
/** GPIO device type */

/** GPIO port A device. */
#define GA               ((gpio_reg *) GPIOA_BASE_ADDR)
/
 /** USART register map type */
typedef struct usart_reg {
     __io uint32 SR;             /**< Status register */
     __io uint32 DR;             /**< Data register */
     __io uint32 BRR;            /**< Baud rate register */
     __io uint32 CR1;            /**< Control register 1 */
     __io uint32 CR2;            /**< Control register 2 */
     __io uint32 CR3;            /**< Control register 3 */
     __io uint32 GTPR;           /**< Guard time and prescaler register */
} usart_reg;

#define USART1_BASE_ADDR                     (0x40013800)
#define U1       					((usart_reg *) USART1_BASE_ADDR)

extern "C" {
extern void SysTick_Handler(void);
extern void USART1_IRQHandler(void);
extern void USART2_IRQHandler(void);
extern void EXTI0_IRQHandler(void);
extern void EXTI1_IRQHandler(void);
extern void EXTI2_IRQHandler(void);
extern void EXTI3_IRQHandler(void);
extern void EXTI4_IRQHandler(void);
extern void EXTI9_5_IRQHandler(void);
extern void EXTI15_10_IRQHandler(void);
extern void USB_LP_IRQHandler(void);
extern void USB_FS_WKUP_IRQHandler(void);
extern void TIM2_IRQHandler(void);
extern void TIM3_IRQHandler(void);
extern void TIM4_IRQHandler(void);
extern void TIM9_IRQHandler(void);
extern void TIM10_IRQHandler(void);
extern void TIM11_IRQHandler(void);

#include "USB\inc\hw_config.h"
#include "USB\USB_Lib\inc\usb_lib.h"
#include "USB\inc\usb_desc.h"
#include "USB\inc\usb_pwr.h"
#include "USB\inc\common_vars.h"

#include "USB\inc\usb_istr.h"

}
int main(void) {

    setup();

    while (1) {
        loop();
    }
    return 0;
}

void LED_BLUE_TOGGLE(void)
{
	GA->ODR = GA->ODR ^ BIT(15);
}
void SysTick_Handler(void)
{
	__exc_systick(); // added ver 31 jason 20160902
}

void USART1_IRQHandler(void)
{
	__irq_usart1();
}

void USART2_IRQHandler(void)
{
	__irq_usart2();
}

void EXTI0_IRQHandler(void)
{
	__irq_exti0();
}

void EXTI1_IRQHandler(void)
{
	__irq_exti1();
}

void EXTI2_IRQHandler(void)
{
	__irq_exti2();
}

void EXTI3_IRQHandler(void)
{
	__irq_exti3();
}

void EXTI4_IRQHandler(void)
{
	__irq_exti4();
}

void EXTI9_5_IRQHandler(void)
{
	__irq_exti9_5();
}

void EXTI15_10_IRQHandler(void)
{
	__irq_exti15_10();
}

void USB_LP_IRQHandler(void)
{
	USB_Istr();
}

void USB_FS_WKUP_IRQHandler(void)
{
	EXTI_STRUCT->PR = BIT(18);
}

void TIM2_IRQHandler(void)
{
	__irq_tim2();
}

void TIM3_IRQHandler(void)
{
	__irq_tim3();
}

void TIM4_IRQHandler(void)
{
	__irq_tim4();
}

void TIM9_IRQHandler(void)
{
	__irq_tim9();
}

void TIM10_IRQHandler(void)
{
	__irq_tim10();
}

void TIM11_IRQHandler(void)
{
	__irq_tim11();
}
