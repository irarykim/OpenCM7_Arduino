/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 Perry Hung.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

/**
 * @file adc.c
 *
 * @brief Analog to digital converter routines
 *
 * IMPORTANT: maximum external impedance must be below 0.4kOhms for 1.5
 * sample conversion time.
 *
 * At 55.5 cycles/sample, the external input impedance < 50kOhms.
 *
 * See STM32 manual RM0008 for how to calculate this.
 */

#include "rcc.h"
#include "adc.h"

static adc_dev adc1 = {
    .regs   = ADC1_BASE,
    .clk_id = RCC_ADC1
};
/** ADC1 device. */
const adc_dev *ADC1 = &adc1;

#ifdef STM32_HIGH_DENSITY
adc_dev adc3 = {
    .regs   = ADC3_BASE,
    .clk_id = RCC_ADC3
};
/** ADC3 device. */
const adc_dev *ADC3 = &adc3;
#endif

/**
 * @brief Initialize an ADC peripheral.
 *
 * Initializes the RCC clock line for the given peripheral.  Resets
 * ADC device registers.
 *
 * @param dev ADC peripheral to initialize
 */
void adc_init(const adc_dev *dev) {
    rcc_clk_enable(dev->clk_id);
    rcc_reset_dev(dev->clk_id);
}

void adc_configuration(const adc_dev *dev) {
	uint32 tmpreg1 = 0;
	uint8 tmpreg2 = 0;

	ADC_InitTypeDef ADC_InitStruct;
	/* Reset ADC init structure parameters values */
	/* Initialize the ADC_Resolution member */
	ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b;

	/* Initialize the ADC_ScanConvMode member */
	ADC_InitStruct.ADC_ScanConvMode = DISABLE;

	/* Initialize the ADC_ContinuousConvMode member */
	ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;

	/* Initialize the ADC_ExternalTrigConvEdge member */
	ADC_InitStruct.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;

	/* Initialize the ADC_ExternalTrigConv member */
	ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T2_CC2;

	/* Initialize the ADC_DataAlign member */
	ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;

	/* Initialize the ADC_NbrOfConversion member */
	ADC_InitStruct.ADC_NbrOfConversion = 1;

	/*---------------------------- ADCx CR1 Configuration -----------------*/
	/* Get the ADCx CR1 value */
	tmpreg1 = dev->regs->CR1;
	/* Clear RES and SCAN bits */
	tmpreg1 &= CR1_CLEAR_MASK;
	/* Configure ADCx: scan conversion mode and resolution */
	/* Set SCAN bit according to ADC_ScanConvMode value */
	/* Set RES bit according to ADC_Resolution value */
	tmpreg1 |= (uint32)(((uint32)ADC_InitStruct.ADC_ScanConvMode << 8) | ADC_InitStruct.ADC_Resolution);
	/* Write to ADCx CR1 */
	dev->regs->CR1 = tmpreg1;

	/*---------------------------- ADCx CR2 Configuration -----------------*/
	/* Get the ADCx CR2 value */
	tmpreg1 = dev->regs->CR2;
	/* Clear CONT, ALIGN, EXTEN and EXTSEL bits */
	tmpreg1 &= CR2_CLEAR_MASK;
	/* Configure ADCx: external trigger event and edge, data alignment and continuous conversion mode */
	/* Set ALIGN bit according to ADC_DataAlign value */
	/* Set EXTEN bits according to ADC_ExternalTrigConvEdge value */
	/* Set EXTSEL bits according to ADC_ExternalTrigConv value */
	/* Set CONT bit according to ADC_ContinuousConvMode value */
	tmpreg1 |= (uint32)(ADC_InitStruct.ADC_DataAlign | ADC_InitStruct.ADC_ExternalTrigConv |
			ADC_InitStruct.ADC_ExternalTrigConvEdge | ((uint32)ADC_InitStruct.ADC_ContinuousConvMode << 1));
	/* Write to ADCx CR2 */
	dev->regs->CR2 = tmpreg1;

	/*---------------------------- ADCx SQR1 Configuration -----------------*/
	/* Get the ADCx SQR1 value */
	tmpreg1 = dev->regs->SQR1;
	/* Clear L bits */
	tmpreg1 &= SQR1_L_RESET;
	/* Configure ADCx: regular channel sequence length */
	/* Set L bits according to ADC_NbrOfConversion value */
	tmpreg2 |= (uint8)(ADC_InitStruct.ADC_NbrOfConversion - (uint8)1);
	tmpreg1 |= ((uint32)tmpreg2 << 20);
	/* Write to ADCx SQR1 */
	dev->regs->SQR1 = tmpreg1;


	uint8 Rank = 1;
	uint8 ADC_Channel = 0;

	/* Get the old register value */
	tmpreg1 = dev->regs->SMPR3;

	for(ADC_Channel = 0; ADC_Channel < 8; ADC_Channel++)
	{
		/* Calculate the mask to clear */
		tmpreg2 = SMPR3_SMP_SET << (3 * ADC_Channel);
		/* Clear the old sample time */
		tmpreg1 &= ~tmpreg2;
		/* Calculate the mask to set */
		tmpreg2 = (uint32)ADC_SMPR_16_CYCLE << (3 * ADC_Channel);
		/* Set the new sample time */
		tmpreg1 |= tmpreg2;
	}
	/* Store the new register value */
	dev->regs->SMPR3 = tmpreg1;

    ADC_Channel = 6;
    /* Get the old register value */
    tmpreg1 = dev->regs->SQR5;
    /* Calculate the mask to clear */
    tmpreg2 = SQR5_SQ_SET << (5 * (Rank - 1));
    /* Clear the old SQx bits for the selected rank */
    tmpreg1 &= ~tmpreg2;
    /* Calculate the mask to set */
    tmpreg2 = (uint32)ADC_Channel << (5 * (Rank - 1));
    /* Set the SQx bits for the selected rank */
    tmpreg1 |= tmpreg2;
    /* Store the new register value */
    dev->regs->SQR5 = tmpreg1;

    uint32 itmask = 0;
    /* Get the ADC IT index */
    itmask = (uint8)ADC_IT_EOC;
    itmask = (uint32)0x01 << itmask;
    dev->regs->CR1 &= (~(uint32)itmask);

	/* Set the ADON bit to wake up the ADC from power down mode */
	dev->regs->CR2 |= (uint32)ADC_CR2_ADON;
}
/**
 * @brief Set external event select for regular group
 * @param dev ADC device
 * @param event Event used to trigger the start of conversion.
 * @see adc_extsel_event
 */
void adc_set_extsel(const adc_dev *dev, adc_extsel_event event) {
    uint32 cr2 = dev->regs->CR2;
    cr2 &= ~ADC_CR2_EXTSEL;
    cr2 |= event;
    dev->regs->CR2 = cr2;
}

/**
 * @brief Call a function on all ADC devices.
 * @param fn Function to call on each ADC device.
 */
void adc_foreach(void (*fn)(const adc_dev*)) {
    fn(ADC1);
}

/**
 * @brief Turn the given sample rate into values for ADC_SMPRx. Don't
 * call this during conversion.
 * @param dev adc device
 * @param smp_rate sample rate to set
 * @see adc_smp_rate
 */
void adc_set_sample_rate(const adc_dev *dev, adc_smp_rate smp_rate) {
	uint32 adc_smpr2_val = 0, adc_smpr3_val = 0;
    int i;

    for (i = 0; i < 14; i++) {
        if (i < 10) {
            /* ADC_SMPR3 determines sample time for channels [0,9] */
        	adc_smpr3_val |= smp_rate << (i * 3);
        }
        /* ADC_SMPR2 determines sample time for channels [10,19] */
        adc_smpr2_val |= smp_rate << ((i - 10) * 3);
    }

    dev->regs->SMPR3 = adc_smpr3_val;
    dev->regs->SMPR2 = adc_smpr2_val;
}

/**
 * @brief Perform a single synchronous software triggered conversion on a
 * channel.
 * @param dev ADC device to use for reading.
 * @param channel channel to convert
 * @return conversion result
 */
uint16 adc_read(const adc_dev *dev, uint8 channel) {
    adc_reg_map *regs = dev->regs;

    //[START] [ROBOTIS] added 20160114
    uint32 tmpreg1,tmpreg2;
    uint8 Rank = 1;
    /* Get the old register value */
    tmpreg1 = regs->SQR5;
    /* Calculate the mask to clear */
    tmpreg2 = SQR5_SQ_SET << (5 * (Rank - 1));
    /* Clear the old SQx bits for the selected rank */
    tmpreg1 &= ~tmpreg2;
    /* Calculate the mask to set */
    tmpreg2 = (uint32)channel << (5 * (Rank - 1));
    /* Set the SQx bits for the selected rank */
    tmpreg1 |= tmpreg2;
    /* Store the new register value */
    regs->SQR5 = tmpreg1;
    //[END] [ROBOTIS] added 20160114

    regs->CR2 |= ADC_CR2_SWSTART;
    while(!(regs->SR & ADC_SR_EOC))
        ;
    return (uint16)(regs->DR & ADC_DR_DATA);
}
