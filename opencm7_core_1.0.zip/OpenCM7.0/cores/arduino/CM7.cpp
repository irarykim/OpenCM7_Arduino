
/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2011 LeafLabs, LLC.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

/**
 * @file   maple.cpp
 * @author Marti Bolivar <mbolivar@leaflabs.com>
 * @brief  Maple PIN_MAP and boardInit().
 */
/*
 *  CM7.cpp ported from CM904.cpp
 *
 *  Created on: 2013. 5. 22.
 *      Author: in2storm
 *
 *  Ported on: 2016. 9. 12
 *      Author: jason
 */

#if defined(BOARD_CM7)
#include "boards.h"

#include "gpio.h"
#include "timer.h"


void boardInit(void) {

	//[ROBOTIS][CHANGE] add here if you want to initialize something
	gpio_set_mode(GPIOA_DEV, 15, GPIO_OUTPUT_PP);
	gpio_write_bit(GPIOA_DEV, 15,1); //LED off when start board
}
extern const stm32_pin_info PIN_MAP[BOARD_NR_GPIO_PINS] = {
//	gpio_dev / timer_dev / adc_dev / gpio_bit / timer_ch / adc_ch
   /* Top header */
	{GPIOA_DEV,   NULL, ADC1,  4, 0,    4}, /* D0/PA4 */
	{GPIOA_DEV, TIMER2, ADC1,  5, 1,    5}, /* D1/PA5 */
	{GPIOA_DEV, TIMER2, ADC1,  0, 1,    0}, /* D2/PA0 */
	{GPIOA_DEV, TIMER2, ADC1,  1, 2,    1}, /* D3/PA1 */
	{GPIOA_DEV, TIMER2, ADC1,  2, 3,    2}, /* D4/PA2 */
	{GPIOA_DEV, TIMER2, ADC1,  3, 4,    3}, /* D5/PA3 */
	{GPIOA_DEV, TIMER3, ADC1,  6, 1,    6}, /* D6/PA6 */
	{GPIOA_DEV, TIMER3, ADC1,  7, 2,    7}, /* D7/PA7 */
	{GPIOB_DEV, TIMER3, ADC1,  0, 3,    8}, /* D8/PB0 */
	{GPIOB_DEV, TIMER3, ADC1,  1, 4,    9}, /* D9/PB1 */

	{GPIOA_DEV,   NULL, NULL,  8, 0, ADCx}, /* D10/PA8 */
	{GPIOA_DEV,   NULL, NULL,  9, 0, ADCx}, /* D11/PA9 */
	{GPIOA_DEV,   NULL, NULL, 10, 0, ADCx}, /* D12/PA10 */
	{GPIOB_DEV, TIMER4, NULL,  8, 3, ADCx}, /* D13/PB8 */
	{GPIOB_DEV, TIMER4, NULL,  9, 4, ADCx}, /* D14/PB9 (LED)*/

	{GPIOA_DEV, TIMER2, NULL, 15, 1, ADCx}, /* D15/PA15 */
	{GPIOA_DEV,   NULL, NULL, 13, 0, ADCx}, /* D16/PA13  */
	{GPIOA_DEV,   NULL, NULL, 14, 0, ADCx}, /* D17/PA14  */
	{GPIOB_DEV,TIMER10, NULL, 12, 1, ADCx}, /* D18/PB12 */
	{GPIOB_DEV, TIMER9, NULL, 13, 1, ADCx}, /* D19/PB13 */
	
	{GPIOB_DEV, TIMER9, NULL, 14, 2, ADCx}, /* D20/PB14 */
	{GPIOB_DEV,TIMER11, NULL, 15, 1, ADCx}, /* D21/PB15 */
	{GPIOC_DEV,   NULL, NULL, 14, 0, ADCx}, /* D22/PC14 */
	{GPIOC_DEV,   NULL, NULL, 15, 0, ADCx}, /* D23/PC15 (User Button)*/
	{GPIOB_DEV,   NULL, NULL, 10, 0, ADCx}, /* D24/PB10 */
	{GPIOB_DEV,   NULL, NULL, 11, 0, ADCx}, /* D25/PB11 */
/*
 * Hidden pin map
 * the below pins are used carefully, need to check schematic of OpenCM9.04
 * */
	{GPIOB_DEV,   NULL, NULL,  5, 0, ADCx}, /* D26/PB5 DXL DIR*/
	{GPIOB_DEV, TIMER4, NULL,  6, 1, ADCx}, /* D27/PB6 DXL TXD*/
	{GPIOB_DEV, TIMER4, NULL,  7, 2, ADCx}, /* D28/PB7 DXL RXD*/
	{GPIOA_DEV,   NULL, NULL, 13, 0, ADCx}, /* D29/PA13 JTAG SWDIO*/
	{GPIOA_DEV,   NULL, NULL, 14, 0, ADCx}  /* D30/PA14 JTAG SWDCLK*/
};


/**
 * [ROBOTIS][CHANGE] 2013-04-22
 * Don't need to use the below variables, I think it is not versatile variable.
 * */
/*extern const uint8 boardPWMPins[] __FLASH__ = {
    0, 1, 2, 3, 5, 6, 7, 8, 9, 11, 12, 14, 24, 27, 28
};

extern const uint8 boardADCPins[] __FLASH__ = {
    0, 1, 2, 3, 10, 11, 12, 15, 16, 17, 18, 19, 20, 27, 28
};

extern const uint8 boardUsedPins[] __FLASH__ = {
    BOARD_LED_PIN, BOARD_BUTTON_PIN, BOARD_JTMS_SWDIO_PIN,
    BOARD_JTCK_SWCLK_PIN, BOARD_JTDI_PIN, BOARD_JTDO_PIN, BOARD_NJTRST_PIN
};*/


#endif



