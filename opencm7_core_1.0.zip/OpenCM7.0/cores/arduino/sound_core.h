/***********************************************************************
* Copyright 2017 ROBOTIS Co.,Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* 
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
***********************************************************************/

#ifndef SOUND_CORE_H_
#define SOUND_CORE_H_

/*******************************************************************************
* File Name          : pwm.h
* Author             : danceww
* Version            : V0.1
* Date               : 2010/08/25
* Description        : This file contains the defines used for PWM
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/

//extern static byte gbpActuatorWriteLength[];
//extern static byte gbpSensorWriteLength[];
//#include "includes.h"
//#include "boards.h"

////#include "flash.h"
//#include "rcc.h"
//#include "nvic.h"
//#include "systick.h"

#include "gpio.h"
//#include "adc.h"
#include "timer.h"
//#include "usb.h"
#include "Arduino-compatibles.h"
/* Includes ------------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
//buzzer

//porting -end

#define	SOUND_INTRO_LENGTH          1
#define	SOUND_INTRO_DATA            36
//#define	SOUND_INTRO_DATA            5

#define	SOUND_MODE_ENTER_LENGTH     1
#define	SOUND_MODE_ENTER_DATA       27
//#define	SOUND_MODE_ENTER_DATA       0

#define	SOUND_LOW_VOLTAGE_LENGTH    255
#define	SOUND_LOW_VOLTAGE_DATA      22


//#define SOUND_ON	{ 	TIM_Cmd(TIM4, ENABLE);	/*TIM_CtrlPWMOutputs(TIM4, ENABLE);*/	TIM4->CNT = 0;	}
//#define SOUND_OFF	{	TIM4->CNT = 0; TIM_Cmd(TIM4, DISABLE);	/*TIM_CtrlPWMOutputs(TIM4, DISABLE);*/	}

#define SOUND_ON	{ 	Timer4.resume();	/*TIM_CtrlPWMOutputs(TIM4, ENABLE);*/	Timer4.setCount(0);	}
#define SOUND_OFF	{	Timer4.pause();	/*TIM_CtrlPWMOutputs(TIM4, DISABLE);*/	}

#define BUTTON_SCALE_MAX 14

void SetupBuzzer(void);
void SetBuzzerIndex(uint8 index);
void SetBuzzerTimer(uint8 time);
uint8 GetBuzzerTimer(void);
void PlayMusic(void);
void PlayDoremi(void);
void SetBuzzer(uint16 periodUs);


extern volatile uint8 gbitRinging;
extern volatile uint8 gbBuzzerData;
extern volatile uint8 gbBuzzerPlayLength;

void __ISR_Buzzer_Manage(void);


//mic

#define MIC_ON		_MIC_ON()
#define MIC_OFF 	_MIC_OFF()

uint8 GetSoundDetectedCount(void);
void ClearSoundDetectedCount(void);
uint8 GetSoundDetectingCount(void);
void _MIC_OFF(void);
void _MIC_ON(void);

void __ISR_MIC_EXTI(void);
extern volatile uint8 gbSoundDetectedCount ;
extern volatile uint8 gbitCounting ;
extern volatile uint8 gbTempSoundDetectedCount ;

#endif /* SOUND_CORE_H_ */
