/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 Perry Hung.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

/**
 * @file nvic.h
 * @brief Nested vector interrupt controller support.
 */

#ifndef _NVIC_H_
#define _NVIC_H_

#include "libpandora_types.h"
#include "util.h"

#ifdef __cplusplus
extern "C"{
#endif

/** NVIC register map type. */
typedef struct nvic_reg_map {
    __io uint32 ISER[8];      /**< Interrupt Set Enable Registers */
    uint32 RESERVED0[24];     /**< Reserved */
    __io uint32 ICER[8];      /**< Interrupt Clear Enable Registers */
    uint32 RSERVED1[24];      /**< Reserved */
    __io uint32 ISPR[8];      /**< Interrupt Set Pending Registers */
    uint32 RESERVED2[24];     /**< Reserved */
    __io uint32 ICPR[8];      /**< Interrupt Clear Pending Registers */
    uint32 RESERVED3[24];     /**< Reserved */
    __io uint32 IABR[8];      /**< Interrupt Active bit Registers */
    uint32 RESERVED4[56];     /**< Reserved */
    __io uint8  IP[240];      /**< Interrupt Priority Registers */
    uint32 RESERVED5[644];    /**< Reserved */
    __io uint32 STIR;         /**< Software Trigger Interrupt Registers */
} nvic_reg_map;

/** NVIC register map base pointer. */

#define NVIC_BASE                       ((struct nvic_reg_map*)0xE000E100)


/**
 * @brief Interrupt vector table interrupt numbers.
 *
 * Each positive-valued enumerator is the position of the
 * corresponding interrupt in the vector table.  Negative-valued
 * enumerators correspond to interrupts controlled by the system
 * handler block.
 *
 * @see scb.h
 */

typedef enum nvic_irq_num
{
/******  Cortex-M3 Processor Exceptions Numbers ******************************************************/
	NVIC_NMI         = -14,    /*!< 2 Non Maskable Interrupt                                */
	NVIC_MEM_MANAGE       = -12,    /*!< 4 Cortex-M3 Memory Management Interrupt                 */
	NVIC_BUS_FAULT               = -11,    /*!< 5 Cortex-M3 Bus Fault Interrupt                         */
	NVIC_USAGE_FAULT             = -10,    /*!< 6 Cortex-M3 Usage Fault Interrupt                       */
	NVIC_SVC                    = -5,     /*!< 11 Cortex-M3 SV Call Interrupt                          */
	NVIC_DEBUG_MON           = -4,     /*!< 12 Cortex-M3 Debug Monitor Interrupt                    */
	NVIC_PEND_SVC                 = -2,     /*!< 14 Cortex-M3 Pend SV Interrupt                          */
	NVIC_SYSTICK                = -1,     /*!< 15 Cortex-M3 System Tick Interrupt                      */

/******  STM32L specific Interrupt Numbers ***********************************************************/
	NVIC_WWDG                   = 0,      /*!< Window WatchDog Interrupt                               */
	NVIC_PVD                    = 1,      /*!< PVD through EXTI Line detection Interrupt               */
	NVIC_TAMPER           = 2,      /*!< Tamper and Time Stamp through EXTI Line Interrupts      */
	NVIC_RTC               = 3,      /*!< RTC Wakeup Timer through EXTI Line Interrupt            */
	NVIC_FLASH                  = 4,      /*!< FLASH global Interrupt                                  */
	NVIC_RCC                    = 5,      /*!< RCC global Interrupt                                    */
	NVIC_EXTI0                  = 6,      /*!< EXTI Line0 Interrupt                                    */
	NVIC_EXTI1                  = 7,      /*!< EXTI Line1 Interrupt                                    */
	NVIC_EXTI2                  = 8,      /*!< EXTI Line2 Interrupt                                    */
	NVIC_EXTI3                  = 9,      /*!< EXTI Line3 Interrupt                                    */
	NVIC_EXTI4                  = 10,     /*!< EXTI Line4 Interrupt                                    */
	NVIC_DMA_CH1          = 11,     /*!< DMA1 Channel 1 global Interrupt                         */
	NVIC_DMA_CH2          = 12,     /*!< DMA1 Channel 2 global Interrupt                         */
	NVIC_DMA_CH3          = 13,     /*!< DMA1 Channel 3 global Interrupt                         */
	NVIC_DMA_CH4          = 14,     /*!< DMA1 Channel 4 global Interrupt                         */
	NVIC_DMA_CH5          = 15,     /*!< DMA1 Channel 5 global Interrupt                         */
	NVIC_DMA_CH6          = 16,     /*!< DMA1 Channel 6 global Interrupt                         */
	NVIC_DMA_CH7          = 17,     /*!< DMA1 Channel 7 global Interrupt                         */
	NVIC_ADC_1                   = 18,     /*!< ADC1 global Interrupt                                   */
	NVIC_USB_HP                 = 19,     /*!< USB High Priority Interrupt                             */
	NVIC_USB_LP                = 20,     /*!< USB Low Priority Interrupt                              */
	NVIC_DAC                    = 21,     /*!< DAC Interrupt                                           */
	NVIC_COMP                   = 22,     /*!< Comparator through EXTI Line Interrupt                  */
	NVIC_EXTI_9_5                = 23,     /*!< External Line[9:5] Interrupts                           */
	NVIC_LCD                    = 24,     /*!< LCD Interrupt                                           */
	NVIC_TIMER9                   = 25,     /*!< TIM9 global Interrupt                                   */
	NVIC_TIMER10                  = 26,     /*!< TIM10 global Interrupt                                  */
	NVIC_TIMER11                  = 27,     /*!< TIM11 global Interrupt                                  */
	NVIC_TIMER2                   = 28,     /*!< TIM2 global Interrupt                                   */
	NVIC_TIMER3                   = 29,     /*!< TIM3 global Interrupt                                   */
	NVIC_TIMER4                   = 30,     /*!< TIM4 global Interrupt                                   */
	NVIC_I2C1_EV                = 31,     /*!< I2C1 Event Interrupt                                    */
	NVIC_I2C1_ER                = 32,     /*!< I2C1 Error Interrupt                                    */
	NVIC_I2C2_EV                = 33,     /*!< I2C2 Event Interrupt                                    */
	NVIC_I2C2_ER                = 34,     /*!< I2C2 Error Interrupt                                    */
	NVIC_SPI1                   = 35,     /*!< SPI1 global Interrupt                                   */
	NVIC_SPI2                   = 36,     /*!< SPI2 global Interrupt                                   */
	NVIC_USART1                 = 37,     /*!< USART1 global Interrupt                                 */
	NVIC_USART2                 = 38,     /*!< USART2 global Interrupt                                 */
	NVIC_USART3                 = 39,     /*!< USART3 global Interrupt                                 */
	NVIC_EXTI_15_10              = 40,     /*!< External Line[15:10] Interrupts                         */
	NVIC_RTCALARM              = 41,     /*!< RTC Alarm through EXTI Line Interrupt                   */
	NVIC_USBWAKEUP            = 42,     /*!< USB FS WakeUp from suspend through EXTI Line Interrupt  */
	NVIC_TIMER6                   = 43,     /*!< TIM6 global Interrupt                                   */
#ifdef STM32L1XX_MD
	NVIC_TIMER7                   = 44      /*!< TIM7 global Interrupt                                   */
#endif

#ifdef STM32L1XX_MDP
	NVIC_TIMER7                   = 44,     /*!< TIM7 global Interrupt                                   */
	NVIC_TIMER5                   = 46,     /*!< TIM5 global Interrupt                                   */
	NVIC_SPI3                   = 47,     /*!< SPI3 global Interrupt                                   */
	NVIC_DMA2_CH1          = 50,     /*!< DMA2 Channel 1 global Interrupt                         */
	NVIC_DMA2_CH2          = 51,     /*!< DMA2 Channel 2 global Interrupt                         */
	NVIC_DMA2_CH3          = 52,     /*!< DMA2 Channel 3 global Interrupt                         */
	NVIC_DMA2_CH4          = 53,     /*!< DMA2 Channel 4 global Interrupt                         */
	NVIC_DMA2_CH5          = 54,     /*!< DMA2 Channel 5 global Interrupt                         */
	NVIC_AES                    = 55,     /*!< AES global Interrupt                                    */
	NVIC_COMP_ACQ               = 56      /*!< Comparator Channel Acquisition global Interrupt         */
#endif

#ifdef STM32L1XX_HD
	NVIC_TIMER7                   = 44,     /*!< TIM7 global Interrupt                                   */
	NVIC_SDIO                   = 45,     /*!< SDIO global Interrupt                                   */
	NVIC_TIMER5                   = 46,     /*!< TIM5 global Interrupt                                   */
	NVIC_SPI3                   = 47,     /*!< SPI3 global Interrupt                                   */
	NVIC_UART4                  = 48,     /*!< UART4 global Interrupt                                  */
	NVIC_UART5                  = 49,     /*!< UART5 global Interrupt                                  */
	NVIC_DMA2_CH1          = 50,     /*!< DMA2 Channel 1 global Interrupt                         */
	NVIC_DMA2_CH2          = 51,     /*!< DMA2 Channel 2 global Interrupt                         */
	NVIC_DMA2_CH3          = 52,     /*!< DMA2 Channel 3 global Interrupt                         */
	NVIC_DMA2_CH4          = 53,     /*!< DMA2 Channel 4 global Interrupt                         */
	NVIC_DMA2_CH5          = 54,     /*!< DMA2 Channel 5 global Interrupt                         */
	NVIC_AES                    = 55,     /*!< AES global Interrupt                                    */
	NVIC_COMP_ACQ               = 56      /*!< Comparator Channel Acquisition global Interrupt         */
#endif
} nvic_irq_num;

void nvic_init(uint32 vector_table_address, uint32 offset);
void nvic_set_vector_table(uint32 address, uint32 offset);
void nvic_irq_set_priority(nvic_irq_num irqn, uint8 priority);

/**
 * Enables interrupts and configurable fault handlers (clear PRIMASK).
 */
static inline void nvic_globalirq_enable() {
    asm volatile("cpsie i");
}

/**
 * Disable interrupts and configurable fault handlers (set PRIMASK).
 */
static inline void nvic_globalirq_disable() {
    asm volatile("cpsid i");
}

/**
 * @brief Enable interrupt irq_num
 * @param irq_num Interrupt to enable
 */
static inline void nvic_irq_enable(nvic_irq_num irq_num) {
    if (irq_num < 0) {
        return;
    }
    NVIC_BASE->ISER[irq_num / 32] = BIT(irq_num % 32);
}

/**
 * @brief Disable interrupt irq_num
 * @param irq_num Interrupt to disable
 */
static inline void nvic_irq_disable(nvic_irq_num irq_num) {
    if (irq_num < 0) {
        return;
    }
    NVIC_BASE->ICER[irq_num / 32] = BIT(irq_num % 32);
}

/**
 * @brief Quickly disable all interrupts.
 *
 * Calling this function is significantly faster than calling
 * nvic_irq_disable() in a loop.
 */
static inline void nvic_irq_disable_all(void) {
    /* Note: This only works up to XL density.  The fix for
     * connectivity line is:
     *
     *     NVIC_BASE->ICER[2] = 0xF;
     *
     * We don't support connectivity line devices (yet), so leave it
     * alone for now.
     */
    NVIC_BASE->ICER[0] = 0xFFFFFFFF;
    NVIC_BASE->ICER[1] = 0xFFFFFFFF;
}

#ifdef __cplusplus
}
#endif

#endif

