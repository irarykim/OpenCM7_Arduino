/***********************************************************************
* Copyright 2017 ROBOTIS Co.,Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* 
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
***********************************************************************/

/*
 * dxl2.h
 *
 *  Created on: 2013. 11. 8.
 *      Author: in2storm
 */

#ifndef DXL2_H_
#define DXL2_H_
#ifdef __cplusplus
extern "C" {
#endif
#include "usart.h"
#include "gpio.h"
#include "dxl_constants.h"


/** DYNAMIXEL device type  */
#define DXL_RX_BUF_SIZE 0x1FF //0x3FF //[ROBOTIS] reduced for memory restrict. 20160108
#define DXL_PARAMETER_BUF_SIZE 128


typedef struct dxl_dev {
/*

	gpio_dev *tx_port;      *< Maple pin's GPIO device
	gpio_dev *rx_port;      *< Maple pin's GPIO device
	gpio_dev *dir_port;      *< Maple pin's GPIO device

	uint8 tx_pin;
	uint8 rx_pin;
	uint8 dir_pin;*/
	volatile uint16 write_pointer;
	volatile uint16 read_pointer;
	uint8 data_buffer[DXL_RX_BUF_SIZE];
	voidFuncPtrUart dxlhandlers;
} dxl_dev;
extern dxl_dev *DXL_DEV1;
extern dxl_dev *DXL_DEV2;
extern dxl_dev *DXL_DEV3;

void dxlInterrupt1(byte data);
void dxlInterrupt2(byte data);
void dxlInterrupt3(byte data);
uint32 dxl_get_baudrate(int baudnum);
unsigned short update_crc(unsigned short crc_accum, unsigned char *data_blk_ptr, unsigned short data_blk_size); // for Dxl 2.0

void PrintBuffer(byte *bpPrintBuffer, byte bLength);

#ifdef __cplusplus
}
#endif
#endif /* DXL2_H_ */
