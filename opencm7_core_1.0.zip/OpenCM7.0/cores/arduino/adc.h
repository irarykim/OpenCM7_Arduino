/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010 Perry Hung.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/

/**
 *  @file adc.h
 *
 *  @brief Analog-to-Digital Conversion (ADC) header.
 */

#ifndef _ADC_H_
#define _ADC_H_

//#include "libpandora.h"
#include "bitband.h"
#include "rcc.h"
#include "util.h"  //for use BIT() macro

#include "var_type.h"

#ifdef __cplusplus
extern "C"{
#endif

typedef struct ADC_InitTypeDef
{
  uint32 ADC_Resolution;                /*!< Selects the resolution of the conversion.
                                               This parameter can be a value of @ref ADC_Resolution */

  FunctionalState ADC_ScanConvMode;       /*!< Specifies whether the conversion is performed in
                                               Scan (multichannel) or Single (one channel) mode.
                                               This parameter can be set to ENABLE or DISABLE */

  FunctionalState ADC_ContinuousConvMode; /*!< Specifies whether the conversion is performed in
                                               Continuous or Single mode.
                                               This parameter can be set to ENABLE or DISABLE. */

  uint32 ADC_ExternalTrigConvEdge;      /*!< Selects the external trigger Edge and enables the
                                               trigger of a regular group. This parameter can be a value
                                               of @ref ADC_external_trigger_edge_for_regular_channels_conversion */

  uint32 ADC_ExternalTrigConv;          /*!< Defines the external trigger used to start the analog
                                               to digital conversion of regular channels. This parameter
                                               can be a value of @ref ADC_external_trigger_sources_for_regular_channels_conversion */

  uint32 ADC_DataAlign;                 /*!< Specifies whether the ADC data alignment is left or right.
                                               This parameter can be a value of @ref ADC_data_align */

  uint8  ADC_NbrOfConversion;           /*!< Specifies the number of ADC conversions that will be done
                                               using the sequencer for regular channel group.
                                               This parameter must range from 1 to 27. */
}ADC_InitTypeDef;

/** @defgroup ADC_Resolution
  * @{
  */
#define ADC_Resolution_12b                         ((uint32)0x00000000)
#define ADC_Resolution_10b                         ((uint32)0x01000000)
#define ADC_Resolution_8b                          ((uint32)0x02000000)
#define ADC_Resolution_6b                          ((uint32)0x03000000)

#define ADC_DataAlign_Right                        ((uint32)0x00000000)
#define ADC_DataAlign_Left                         ((uint32)0x00000800)

/* ADC DISCNUM mask */
#define CR1_DISCNUM_RESET         ((uint32)0xFFFF1FFF)

/* ADC AWDCH mask */
#define CR1_AWDCH_RESET           ((uint32)0xFFFFFFE0)

/* ADC Analog watchdog enable mode mask */
#define CR1_AWDMODE_RESET         ((uint32)0xFF3FFDFF)

/* CR1 register Mask */
#define CR1_CLEAR_MASK            ((uint32)0xFCFFFEFF)

/* ADC DELAY mask */
#define CR2_DELS_RESET            ((uint32)0xFFFFFF0F)

/* ADC JEXTEN mask */
#define CR2_JEXTEN_RESET          ((uint32)0xFFCFFFFF)

/* ADC JEXTSEL mask */
#define CR2_JEXTSEL_RESET         ((uint32)0xFFF0FFFF)

/* CR2 register Mask */
#define CR2_CLEAR_MASK            ((uint32)0xC0FFF7FD)

/* ADC SQx mask */
#define SQR5_SQ_SET               ((uint32)0x0000001F)
#define SQR4_SQ_SET               ((uint32)0x0000001F)
#define SQR3_SQ_SET               ((uint32)0x0000001F)
#define SQR2_SQ_SET               ((uint32)0x0000001F)
#define SQR1_SQ_SET               ((uint32)0x0000001F)

/* ADC L Mask */
#define SQR1_L_RESET              ((uint32)0xFE0FFFFF)

/* ADC JSQx mask */
#define JSQR_JSQ_SET              ((uint32)0x0000001F)

/* ADC JL mask */
#define JSQR_JL_SET               ((uint32)0x00300000)
#define JSQR_JL_RESET             ((uint32)0xFFCFFFFF)

/* ADC SMPx mask */
#define SMPR1_SMP_SET             ((uint32)0x00000007)
#define SMPR2_SMP_SET             ((uint32)0x00000007)
#define SMPR3_SMP_SET             ((uint32)0x00000007)
#define SMPR0_SMP_SET             ((uint32)0x00000007)

/* ADC JDRx registers offset */
#define JDR_OFFSET                ((uint8)0x30)

/* ADC CCR register Mask */
#define CR_CLEAR_MASK             ((uint32)0xFFFCFFFF)

/** @defgroup ADC_interrupts_definition
  * @{
  */

#define ADC_IT_AWD                                 ((uint16)0x0106)
#define ADC_IT_EOC                                 ((uint16)0x0205)
#define ADC_IT_JEOC                                ((uint16)0x0407)
#define ADC_IT_OVR                                 ((uint16)0x201A)

/** ADC register map type. */
typedef struct adc_reg_map
{
  __io uint32 SR;           /*!< ADC status register,                         Address offset: 0x00 */
  __io uint32 CR1;          /*!< ADC control register 1,                      Address offset: 0x04 */
  __io uint32 CR2;          /*!< ADC control register 2,                      Address offset: 0x08 */
  __io uint32 SMPR1;        /*!< ADC sample time register 1,                  Address offset: 0x0C */
  __io uint32 SMPR2;        /*!< ADC sample time register 2,                  Address offset: 0x10 */
  __io uint32 SMPR3;        /*!< ADC sample time register 3,                  Address offset: 0x14 */
  __io uint32 JOFR1;        /*!< ADC injected channel data offset register 1, Address offset: 0x18 */
  __io uint32 JOFR2;        /*!< ADC injected channel data offset register 2, Address offset: 0x1C */
  __io uint32 JOFR3;        /*!< ADC injected channel data offset register 3, Address offset: 0x20 */
  __io uint32 JOFR4;        /*!< ADC injected channel data offset register 4, Address offset: 0x24 */
  __io uint32 HTR;          /*!< ADC watchdog higher threshold register,      Address offset: 0x28 */
  __io uint32 LTR;          /*!< ADC watchdog lower threshold register,       Address offset: 0x2C */
  __io uint32 SQR1;         /*!< ADC regular sequence register 1,             Address offset: 0x30 */
  __io uint32 SQR2;         /*!< ADC regular sequence register 2,             Address offset: 0x34 */
  __io uint32 SQR3;         /*!< ADC regular sequence register 3,             Address offset: 0x38 */
  __io uint32 SQR4;         /*!< ADC regular sequence register 4,             Address offset: 0x3C */
  __io uint32 SQR5;         /*!< ADC regular sequence register 5,             Address offset: 0x40 */
  __io uint32 JSQR;         /*!< ADC injected sequence register,              Address offset: 0x44 */
  __io uint32 JDR1;         /*!< ADC injected data register 1,                Address offset: 0x48 */
  __io uint32 JDR2;         /*!< ADC injected data register 2,                Address offset: 0x4C */
  __io uint32 JDR3;         /*!< ADC injected data register 3,                Address offset: 0x50 */
  __io uint32 JDR4;         /*!< ADC injected data register 4,                Address offset: 0x54 */
  __io uint32 DR;           /*!< ADC regular data register,                   Address offset: 0x58 */
  __io uint32 SMPR0;        /*!< ADC sample time register 0,                  Address offset: 0x5C */
} adc_reg_map;

/** ADC device type. */
typedef struct adc_dev {
    adc_reg_map *regs; /**< Register map */
    rcc_clk_id clk_id; /**< RCC clock information */
} adc_dev;

extern const adc_dev *ADC1;

/*
 * Register map base pointers
 */

/** ADC1 register map base pointer. */
#define ADC1_BASE                       ((struct adc_reg_map*)0x40012400)

#ifdef STM32_HIGH_DENSITY
/** ADC3 register map base pointer. */
#define ADC3_BASE                       ((struct adc_reg_map*)0x40013C00)
#endif

/*
 * Register bit definitions
 */

/* Status register */
#define  ADC_SR_AWD_BIT                      0
#define  ADC_SR_EOC_BIT                      1
#define  ADC_SR_JEOC_BIT                     2
#define  ADC_SR_JSTRT_BIT                    3
#define  ADC_SR_STRT_BIT                     4
#define  ADC_SR_OVR_BIT                      5
#define  ADC_SR_ADONS_BIT                    6
#define  ADC_SR_RCNR_BIT                     8
#define  ADC_SR_JCNR_BIT                     9

#define  ADC_SR_AWD                          BIT(ADC_SR_AWD_BIT)        /*!< Analog watchdog flag */
#define  ADC_SR_EOC                          BIT(ADC_SR_EOC_BIT)        /*!< End of conversion */
#define  ADC_SR_JEOC                         BIT(ADC_SR_JEOC_BIT)        /*!< Injected channel end of conversion */
#define  ADC_SR_JSTRT                        BIT(ADC_SR_JSTRT_BIT)        /*!< Injected channel Start flag */
#define  ADC_SR_STRT                         BIT(ADC_SR_STRT_BIT)        /*!< Regular channel Start flag */
#define  ADC_SR_OVR                          BIT(ADC_SR_OVR_BIT)        /*!< Overrun flag */
#define  ADC_SR_ADONS                        BIT(ADC_SR_ADONS_BIT)        /*!< ADC ON status */
#define  ADC_SR_RCNR                         BIT(ADC_SR_RCNR_BIT)        /*!< Regular channel not ready flag */
#define  ADC_SR_JCNR                         BIT(ADC_SR_JCNR_BIT)        /*!< Injected channel not ready flag */

/* Control register 1 */

#define  ADC_CR1_EOCIE_BIT                       5
#define  ADC_CR1_AWDIE_BIT                       6
#define  ADC_CR1_JEOCIE_BIT                      7
#define  ADC_CR1_SCAN_BIT                        8
#define  ADC_CR1_AWDSGL_BIT                      9
#define  ADC_CR1_JAUTO_BIT                       10
#define  ADC_CR1_DISCEN_BIT                      11
#define  ADC_CR1_JDISCEN_BIT                     12

#define  ADC_CR1_PDD_BIT                         16
#define  ADC_CR1_PDI_BIT                         17

#define  ADC_CR1_JAWDEN_BIT                      22
#define  ADC_CR1_AWDEN_BIT                       23

#define  ADC_CR1_OVRIE_BIT                       26

#define  ADC_CR1_AWDCH                       (0x1F)      					/*!< AWDCH[4:0] bits (Analog watchdog channel select bits) */

#define  ADC_CR1_EOCIE                       BIT(ADC_CR1_EOCIE_BIT)        /*!< Interrupt enable for EOC */
#define  ADC_CR1_AWDIE                       BIT(ADC_CR1_AWDIE_BIT)        /*!< Analog Watchdog interrupt enable */
#define  ADC_CR1_JEOCIE                      BIT(ADC_CR1_JEOCIE_BIT)        /*!< Interrupt enable for injected channels */
#define  ADC_CR1_SCAN                        BIT(ADC_CR1_SCAN_BIT)        /*!< Scan mode */
#define  ADC_CR1_AWDSGL                      BIT(ADC_CR1_AWDSGL_BIT)        /*!< Enable the watchdog on a single channel in scan mode */
#define  ADC_CR1_JAUTO                       BIT(ADC_CR1_JAUTO_BIT)        /*!< Automatic injected group conversion */
#define  ADC_CR1_DISCEN                      BIT(ADC_CR1_DISCEN_BIT)        /*!< Discontinuous mode on regular channels */
#define  ADC_CR1_JDISCEN                     BIT(ADC_CR1_JDISCEN_BIT)        /*!< Discontinuous mode on injected channels */

#define  ADC_CR1_DISCNUM                     (0xE000)			        /*!< DISCNUM[2:0] bits (Discontinuous mode channel count) */

#define  ADC_CR1_PDD                         BIT(ADC_CR1_PDD_BIT)        /*!< Power Down during Delay phase */
#define  ADC_CR1_PDI                         BIT(ADC_CR1_PDI_BIT)        /*!< Power Down during Idle phase */

#define  ADC_CR1_JAWDEN                      BIT(ADC_CR1_JAWDEN_BIT)        /*!< Analog watchdog enable on injected channels */
#define  ADC_CR1_AWDEN                       BIT(ADC_CR1_AWDEN_BIT)        /*!< Analog watchdog enable on regular channels */

#define  ADC_CR1_OVRIE                       BIT(ADC_CR1_OVRIE_BIT)        /*!< Overrun interrupt enable */

/* Control register 2 */
#define  ADC_CR2_ADON_BIT                   0
#define  ADC_CR2_CONT_BIT                   1
#define  ADC_CR2_CFG_BIT                    2

#define  ADC_CR2_DMA_BIT                    8
#define  ADC_CR2_DDS_BIT                    9
#define  ADC_CR2_EOCS_BIT                   10
#define  ADC_CR2_ALIGN_BIT                  11

#define  ADC_CR2_JSWSTART_BIT               22

#define  ADC_CR2_SWSTART_BIT                30

#define  ADC_CR2_ADON                       BIT(ADC_CR2_ADON_BIT)        /*!< A/D Converter ON / OFF */
#define  ADC_CR2_CONT                       BIT(ADC_CR2_CONT_BIT)        /*!< Continuous Conversion */
#define  ADC_CR2_CFG                        BIT(ADC_CR2_CFG_BIT)        /*!< ADC Configuration */

#define  ADC_CR2_DELS                       (0x70)        /*!< DELS[2:0] bits (Delay selection) */

#define  ADC_CR2_DMA                        BIT(ADC_CR2_DMA_BIT)        /*!< Direct Memory access mode */
#define  ADC_CR2_DDS                        BIT(ADC_CR2_DDS_BIT)        /*!< DMA disable selection (Single ADC) */
#define  ADC_CR2_EOCS                       BIT(ADC_CR2_EOCS_BIT)        /*!< End of conversion selection */
#define  ADC_CR2_ALIGN                      BIT(ADC_CR2_ALIGN_BIT)        /*!< Data Alignment */

#define  ADC_CR2_JEXTSEL                    (0xF0000)        /*!< JEXTSEL[3:0] bits (External event select for injected group) */

#define  ADC_CR2_JEXTEN                     (0x300000)        /*!< JEXTEN[1:0] bits (External Trigger Conversion mode for injected channels) */

#define  ADC_CR2_JSWSTART                   BIT(ADC_CR2_JSWSTART_BIT)        /*!< Start Conversion of injected channels */

#define  ADC_CR2_EXTSEL                     (0xF000000)        /*!< EXTSEL[3:0] bits (External Event Select for regular group) */
/* TIM2 */
#define ADC_ExternalTrigConv_T2_CC3                (0x02000000)
#define ADC_ExternalTrigConv_T2_CC2                (0x03000000)
#define ADC_ExternalTrigConv_T2_TRGO               (0x06000000)

/* TIM3 */
#define ADC_ExternalTrigConv_T3_CC1                (0x07000000)
#define ADC_ExternalTrigConv_T3_CC3                (0x08000000)
#define ADC_ExternalTrigConv_T3_TRGO               (0x04000000)

/* TIM4 */
#define ADC_ExternalTrigConv_T4_CC4                (0x05000000)
#define ADC_ExternalTrigConv_T4_TRGO               (0x09000000)

/* TIM6 */
#define ADC_ExternalTrigConv_T6_TRGO               (0x0A000000)

/* TIM9 */
#define ADC_ExternalTrigConv_T9_CC2                (0x00000000)
#define ADC_ExternalTrigConv_T9_TRGO               (0x01000000)

/* EXTI */
#define ADC_ExternalTrigConv_Ext_IT11              (0x0F000000)

#define  ADC_CR2_EXTEN                             (0x30000000)        /*!< EXTEN[1:0] bits (External Trigger Conversion mode for regular channels) */

#define ADC_ExternalTrigConvEdge_None              (0x00000000)
#define ADC_ExternalTrigConvEdge_Rising            (0x10000000)
#define ADC_ExternalTrigConvEdge_Falling           (0x20000000)
#define ADC_ExternalTrigConvEdge_RisingFalling     (0x30000000)

#define  ADC_CR2_SWSTART                    BIT(ADC_CR2_SWSTART_BIT)        /*!< Start Conversion of regular channels */

/* Sample time register 1 */

#define ADC_SMPR1_SMP17                 (0x7 << 21)
#define ADC_SMPR1_SMP16                 (0x7 << 18)
#define ADC_SMPR1_SMP15                 (0x7 << 15)
#define ADC_SMPR1_SMP14                 (0x7 << 12)
#define ADC_SMPR1_SMP13                 (0x7 << 9)
#define ADC_SMPR1_SMP12                 (0x7 << 6)
#define ADC_SMPR1_SMP11                 (0x7 << 3)
#define ADC_SMPR1_SMP10                 0x7

/* Sample time register 2 */

#define ADC_SMPR2_SMP9                  (0x7 << 27)
#define ADC_SMPR2_SMP8                  (0x7 << 24)
#define ADC_SMPR2_SMP7                  (0x7 << 21)
#define ADC_SMPR2_SMP6                  (0x7 << 18)
#define ADC_SMPR2_SMP5                  (0x7 << 15)
#define ADC_SMPR2_SMP4                  (0x7 << 12)
#define ADC_SMPR2_SMP3                  (0x7 << 9)
#define ADC_SMPR2_SMP2                  (0x7 << 6)
#define ADC_SMPR2_SMP1                  (0x7 << 3)
#define ADC_SMPR2_SMP0                  0x7

/* Injected channel data offset register */

#define ADC_JOFR_JOFFSET                0x3FF

/* Watchdog high threshold register */

#define ADC_HTR_HT                      0x3FF

/* Watchdog low threshold register */

#define ADC_LTR_LT                      0x3FF

/* Regular sequence register 1 */

#define ADC_SQR1_L                      (0x1F << 20)
#define ADC_SQR1_SQ16                   (0x1F << 15)
#define ADC_SQR1_SQ15                   (0x1F << 10)
#define ADC_SQR1_SQ14                   (0x1F << 5)
#define ADC_SQR1_SQ13                   0x1F

/* Regular sequence register 2 */

#define ADC_SQR2_SQ12                   (0x1F << 25)
#define ADC_SQR2_SQ11                   (0x1F << 20)
#define ADC_SQR2_SQ10                   (0x1F << 16)
#define ADC_SQR2_SQ9                    (0x1F << 10)
#define ADC_SQR2_SQ8                    (0x1F << 5)
#define ADC_SQR2_SQ7                    0x1F

/* Regular sequence register 3 */

#define ADC_SQR3_SQ6                    (0x1F << 25)
#define ADC_SQR3_SQ5                    (0x1F << 20)
#define ADC_SQR3_SQ4                    (0x1F << 16)
#define ADC_SQR3_SQ3                    (0x1F << 10)
#define ADC_SQR3_SQ2                    (0x1F << 5)
#define ADC_SQR3_SQ1                    0x1F

/* Injected sequence register */

#define ADC_JSQR_JL                     (0x3 << 20)
#define ADC_JSQR_JL_1CONV               (0x0 << 20)
#define ADC_JSQR_JL_2CONV               (0x1 << 20)
#define ADC_JSQR_JL_3CONV               (0x2 << 20)
#define ADC_JSQR_JL_4CONV               (0x3 << 20)
#define ADC_JSQR_JSQ4                   (0x1F << 15)
#define ADC_JSQR_JSQ3                   (0x1F << 10)
#define ADC_JSQR_JSQ2                   (0x1F << 5)
#define ADC_JSQR_JSQ1                   0x1F

/* Injected data registers */

#define ADC_JDR_JDATA                   0xFFFF

/* Regular data register */

#define ADC_DR_ADC2DATA                 (0xFFFF << 16)
#define ADC_DR_DATA                     0xFFFF

void adc_init(const adc_dev *dev);
void adc_configuration(const adc_dev *dev);
/**
 * @brief External event selector for regular group conversion.
 * @see adc_set_extsel
 */
typedef enum adc_extsel_event {
    ADC_ADC1_TIM9_CC2   = (0 << 16), /**< ADC1: Timer 9 CC2 event */
    ADC_ADC1_TIM9_TRGO  = (1 << 16), /**< ADC1: Timer 9 TRGO event */
    ADC_ADC1_TIM2_CC3   = (2 << 16), /**< ADC1: Timer 2 CC3 event */
    ADC_ADC1_TIM2_CC2   = (3 << 16), /**< ADC1: Timer 2 CC2 event */
    ADC_ADC1_TIM3_TRGO  = (4 << 16), /**< ADC1: Timer 3 TRGO event */
    ADC_ADC1_TIM4_CC4   = (5 << 16), /**< ADC1: Timer 4 CC4 event */
    ADC_ADC1_TIM2_TRGO  = (6 << 16), /**< ADC1: Timer 2 TRGO event */
    ADC_ADC1_TIM3_CC1   = (7 << 16), /**< ADC1: Timer 3 CC1 event */
    ADC_ADC1_TIM3_CC3   = (8 << 16), /**< ADC1: Timer 3 CC3 event */
    ADC_ADC1_TIM4_TRGO  = (9 << 16), /**< ADC1: Timer 4 TRGO event */
    ADC_ADC1_TIM6_TRGO  = (10 << 16), /**< ADC1: Timer 6 TRGO event */

    ADC_ADC1_EXTI11     = (15 << 16), /**< ADC1: EXTI11 event */
} adc_extsel_event;

void adc_set_extsel(const adc_dev *dev, adc_extsel_event event);
void adc_foreach(void (*fn)(const adc_dev*));

/**
 * @brief ADC sample times, in ADC clock cycles
 *
 * These control the amount of time spent sampling the input voltage.
 */
typedef enum {
    ADC_SMPR_4_CYCLE = 0x00,               /**< 4 ADC cycles */
    ADC_SMPR_9_CYCLE = 0x01,               /**< 9 ADC cycles */
    ADC_SMPR_16_CYCLE = 0x02,              /**< 16 ADC cycles */
    ADC_SMPR_24_CYCLE = 0x03,              /**< 24 ADC cycles */
    ADC_SMPR_48_CYCLE = 0x04,              /**< 48 ADC cycles */
    ADC_SMPR_96_CYCLE = 0x05,              /**< 96 ADC cycles */
    ADC_SMPR_192_CYCLE = 0x06,             /**< 192 ADC cycles */
    ADC_SMPR_384_CYCLE  = 0x07,             /**< 384 ADC cycles */
} adc_smp_rate;

void adc_set_sample_rate(const adc_dev *dev, adc_smp_rate smp_rate);
void adc_calibrate(const adc_dev *dev);
uint16 adc_read(const adc_dev *dev, uint8 channel);

/**
 * @brief Set the regular channel sequence length.
 *
 * Defines the total number of conversions in the regular channel
 * conversion sequence.
 *
 * @param dev ADC device.
 * @param length Regular channel sequence length, from 1 to 16.
 */
static inline void adc_set_reg_seqlen(const adc_dev *dev, uint8 length) {
    uint32 tmp = dev->regs->SQR1;
    tmp &= ~ADC_SQR1_L;
    tmp |= (length - 1) << 20;
    dev->regs->SQR1 = tmp;
}

/**
 * @brief Set external trigger conversion mode event for regular channels
 * @param dev    ADC device
 * @param enable If 1, conversion on external events is enabled; if 0,
 *               disabled.
 */
static inline void adc_set_exttrig(const adc_dev *dev) {
//static inline void adc_set_exttrig(const adc_dev *dev, uint8 enable) {
    uint32 cr2 = dev->regs->CR2;
    cr2 &= ~ADC_CR2_EXTEN;
    cr2 |= ADC_ExternalTrigConvEdge_None;  // [ROBOTIS] disable ext trig. 20151128
    dev->regs->CR2 = cr2;
    //*bb_perip(&dev->regs->CR2, ADC_CR2_EXTTRIG_BIT) = !!enable;
}

/**
 * @brief Enable an adc peripheral
 * @param dev ADC device to enable
 */
static inline void adc_enable(const adc_dev *dev) {
    *bb_perip(&dev->regs->CR2, ADC_CR2_ADON_BIT) = 1;
}

/**
 * @brief Disable an ADC peripheral
 * @param dev ADC device to disable
 */
static inline void adc_disable(const adc_dev *dev) {
    *bb_perip(&dev->regs->CR2, ADC_CR2_ADON_BIT) = 0;
}

/**
 * @brief Disable all ADC peripherals.
 */
static inline void adc_disable_all(void) {
    adc_foreach(adc_disable);
}

#ifdef __cplusplus
} // extern "C"
#endif

#endif
