/*
 * common_vars.h
 *
 *  Created on: 2015. 9. 24.
 *      Author: Administrator
 */

#ifndef SRC_COMMON_VARS_H_
#define SRC_COMMON_VARS_H_

#include "hw_config.h"
//#include "var_type.h"

typedef signed long      s32;
typedef signed short     s16;
typedef signed char      s8;

typedef volatile signed long      vs32;
typedef volatile signed short     vs16;
typedef volatile signed char      vs8;

typedef unsigned long       u32;
typedef unsigned short      u16;
typedef unsigned char       u8;

typedef unsigned long  const    uc32;  /* Read Only */
typedef unsigned short const    uc16;  /* Read Only */
typedef unsigned char  const    uc8;   /* Read Only */

typedef volatile unsigned long      vu32;
typedef volatile unsigned short     vu16;
typedef volatile unsigned char      vu8;

typedef volatile unsigned long  const    vuc32;  /* Read Only */
typedef volatile unsigned short const    vuc16;  /* Read Only */
typedef volatile unsigned char  const    vuc8;   /* Read Only */

//typedef enum
//{
//  FALSE = 0, TRUE  = !FALSE
//}
//bool;

//typedef enum { RESET = 0, SET   = !RESET } FlagStatus, ITStatus;

//typedef enum { DISABLE = 0, ENABLE  = !DISABLE} FunctionalState;
//
//typedef enum { ERROR = 0, SUCCESS  = !ERROR} ErrorStatus;

#define USB_RX_DATA_BUFFER_SIZE        (512)

#define FLASH_START_ADDRESS ((u32)0x8005000)
#define FLASH_END_ADDRESS	((u32)0x0800FFFF)
#define FLASH_PAGE_SIZE    	((u32)0x100)
#define FLASH_HALF_PAGE_SIZE ((u32)0x80)

#define EEPROM_START_ADDRESS	((u32)0x8080000)

extern u8 usbRxDataBuffer[USB_RX_DATA_BUFFER_SIZE];
//extern u8 usbRxFlashBuffer[USB_RX_DATA_BUFFER_SIZE];
extern vu16 usbRxDataReadPointer, usbRCRxDataReadPointer, usbRxDataWritePointer;  // added 20150924 jason
extern vu16 usbRxFlashReadPointer, usbRxFlashWritePointer;  // added 20150926 jason
extern u8 usbRxDataWriteCounter;
extern u8 usbRxFlashWriteCounter;

extern volatile u16 USB_Rx_Cnt;  // added 20150924 jason

extern volatile uint32 countTx;  // added 20160102 jason

//extern volatile u16 gwpUSARTBuffer[USART_BUFFER_SIZE+1];
extern volatile u16 gwUSARTReadPtr, gwUSARTWritePtr;

extern vu32  gu32TimingCounter1ms;
extern u8 gb1msTimerSwitch;

extern bool gbFlashDownloadStart;
extern bool gbSaveToUsbBuffer;
extern bool gbIsFlashLock;

extern vu32 glAddressPointer, glRxTotalCount, glReceivedCheckSumFromHost,glCheckSum;
extern vu32 glCalculatedCheckSum;

extern vu32 lStartBlockAddress, lEndBlockAddress;

extern uint8 line_dtr_rts;

extern uint8 USB_Rx_Buffer[64/*VIRTUAL_COM_PORT_DATA_SIZE*/];
#endif /* SRC_COMMON_VARS_H_ */
