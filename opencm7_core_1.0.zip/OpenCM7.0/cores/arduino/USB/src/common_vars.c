/*
 * common_vars.c
 *
 *  Created on: 2015. 9. 24.
 *      Author: Administrator
 */

#include "USB\inc\common_vars.h"

//#include "usb_type.h"

u8 usbRxDataBuffer[USB_RX_DATA_BUFFER_SIZE];
//u8 usbRxFlashBuffer[USB_RX_DATA_BUFFER_SIZE];
vu16 usbRxDataReadPointer = 0, usbRCRxDataReadPointer = 0, usbRxDataWritePointer = 0;  // added 20150924 jason
vu16 usbRxFlashReadPointer = 0, usbRxFlashWritePointer = 0;  // added 20150926 jason
u8 usbRxDataWriteCounter;
u8 usbRxFlashWriteCounter;

volatile u16 USB_Rx_Cnt =0;  // added 20150924 jason

volatile uint32 countTx = 0; // added 20160102 jason

//volatile u16 gwpUSARTBuffer[USART_BUFFER_SIZE+1];
volatile u16 gwUSARTReadPtr, gwUSARTWritePtr;

vu32  gu32TimingCounter1ms = 0;
u8 gb1msTimerSwitch=0;

bool gbFlashDownloadStart = FALSE;
bool gbSaveToUsbBuffer = FALSE;
bool gbIsFlashLock = TRUE;

vu32 glAddressPointer=0, glRxTotalCount=0, glReceivedCheckSumFromHost=0,glCheckSum = 0;
vu32 glCalculatedCheckSum=0;

vu32 lStartBlockAddress, lEndBlockAddress;

uint8 line_dtr_rts = 0;
