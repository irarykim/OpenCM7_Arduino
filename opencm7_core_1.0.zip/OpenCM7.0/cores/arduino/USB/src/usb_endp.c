/**
  ******************************************************************************
  * @file    usb_endp.c
  * @author  MCD Application Team
  * @version V4.0.0
  * @date    21-January-2013
  * @brief   Endpoint routines
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/
//#include "led.h"
#include "USB\USB_Lib\inc\usb_lib.h"
#include "USB\inc\usb_desc.h"
#include "USB\USB_Lib\inc\usb_mem.h"
#include "USB\inc\hw_config.h"
#include "USB\inc\usb_istr.h"
#include "USB\inc\usb_pwr.h"
#include "USB\inc\usb_prop.h"
#include "USB\inc\iwdg.h"

#include "USB\inc\common_vars.h"

#include "gpio.h"
#include "usb.h"
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

/* Interval between sending IN packets in frame number (1 frame = 1ms) */
#define VCOMPORT_IN_FRAME_INTERVAL             5

#define VCOM_RX_ENDP              ENDP3
#define VCOM_RX_EPNUM             0x03
#define VCOM_RX_ADDR              0x110
#define VCOM_RX_EPSIZE            0x40
#define VCOM_RX_BUFLEN            (VCOM_RX_EPSIZE*3)

#define EP1R  *((volatile unsigned int *)(0x40005C04))
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

uint8 USB_Rx_Buffer[VIRTUAL_COM_PORT_DATA_SIZE];

RESET_STATE reset_state = DTR_UNSET;

extern  uint8 USART_Rx_Buffer[];
extern uint32 USART_Rx_ptr_out;
extern uint32 USART_Rx_length;
extern uint8  USB_Tx_State;

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
//bool WriteFlash64(uint8* RxBuffer, u16 RxCount );
bool WriteFlash128();

/*******************************************************************************
* Function Name  : EP1_IN_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP1_IN_Callback (void)
{
	/*
  uint16 USB_Tx_ptr;
  uint16 USB_Tx_length;
  
  if (USB_Tx_State == 1)
  {
    if (USART_Rx_length == 0) 
    {
      USB_Tx_State = 0;
    }
    else 
    {
      if (USART_Rx_length > VIRTUAL_COM_PORT_DATA_SIZE){
        USB_Tx_ptr = USART_Rx_ptr_out;
        USB_Tx_length = VIRTUAL_COM_PORT_DATA_SIZE;
        
        USART_Rx_ptr_out += VIRTUAL_COM_PORT_DATA_SIZE;
        USART_Rx_length -= VIRTUAL_COM_PORT_DATA_SIZE;    
      }
      else 
      {
        USB_Tx_ptr = USART_Rx_ptr_out;
        USB_Tx_length = USART_Rx_length;
        
        USART_Rx_ptr_out += USART_Rx_length;
        USART_Rx_length = 0;
      }
      UserToPMABufferCopy(&USART_Rx_Buffer[USB_Tx_ptr], ENDP1_TXADDR, USB_Tx_length);
      SetEPTxCount(ENDP1, USB_Tx_length);
      SetEPTxValid(ENDP1); 
    }
  }
  */
	countTx = 0;  // [ROBOTIS] added 20160102
}

/*******************************************************************************
* Function Name  : EP3_OUT_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void EP3_OUT_Callback(void)
{
  //uint16 USB_Rx_Cnt;  // commented 20150924 jason
  
  /* Get the received data buffer and update the counter */
  USB_Rx_Cnt = USB_SIL_Read(EP3_OUT, USB_Rx_Buffer);

  /* USB data will be immediately processed, this allow next USB traffic being 
  NAKed till the end of the USART Xfer */
  
  //USB_To_USART_Send_Data(USB_Rx_Buffer, USB_Rx_Cnt);
  /*
	if(gbFlashDownloadStart == TRUE){
		ClearTimeOutBuffer();
		if(usbRxFlashWritePointer + USB_Rx_Cnt  <= USB_RX_DATA_BUFFER_SIZE)
		{
			for(usbRxFlashWriteCounter = 0; usbRxFlashWriteCounter < USB_Rx_Cnt; usbRxFlashWriteCounter++)
			{
				usbRxFlashBuffer[usbRxFlashWritePointer + usbRxFlashWriteCounter] = USB_Rx_Buffer[usbRxFlashWriteCounter];
				glCalculatedCheckSum += USB_Rx_Buffer[usbRxFlashWriteCounter];
			}
			usbRxFlashWritePointer = usbRxFlashWritePointer + USB_Rx_Cnt;
		}
		else
		{
			for(usbRxFlashWriteCounter = 0; usbRxFlashWriteCounter < USB_RX_DATA_BUFFER_SIZE - usbRxFlashWritePointer; usbRxFlashWriteCounter++)
			{
				usbRxFlashBuffer[usbRxFlashWritePointer + usbRxFlashWriteCounter] = USB_Rx_Buffer[usbRxFlashWriteCounter];
				glCalculatedCheckSum += USB_Rx_Buffer[usbRxFlashWriteCounter];
			}
			for(usbRxFlashWriteCounter = 0; usbRxFlashWriteCounter < usbRxFlashWritePointer + USB_Rx_Cnt - USB_RX_DATA_BUFFER_SIZE; usbRxFlashWriteCounter++)
			{
				usbRxFlashBuffer[usbRxFlashWriteCounter] = USB_Rx_Buffer[USB_RX_DATA_BUFFER_SIZE - usbRxFlashWritePointer + usbRxFlashWriteCounter];
				glCalculatedCheckSum += usbRxFlashBuffer[usbRxFlashWriteCounter];
			}
			usbRxFlashWritePointer = usbRxFlashWritePointer + USB_Rx_Cnt;
			usbRxFlashWritePointer = usbRxDataWritePointer & (USB_RX_DATA_BUFFER_SIZE - 1);
		}
		glRxTotalCount += USB_Rx_Cnt;

		WriteFlash128();
	}
	else
		gwpUSARTBuffer[gwUSARTWritePtr++&USART_BUFFER_SIZE] = USB_Rx_Buffer[0]; */
	//TxDString("gwUSARTWritePtr = ");	TxDHex32(gwpUSARTBuffer[gwUSARTWritePtr-1]);	TxDString("\r\n");
	u8 chkBuf[4]={0,0,0,0}; //[ROBOTIS]add to initialize chkBuf[] as 0x0
	u8 cmpBuf[4] = {0x43,0x4D,0x39,0x58};//{0x31, 0x45, 0x41, 0x46};
	if (reset_state == DTR_NEGEDGE) {
		reset_state = DTR_LOW;
//		if  (newBytes >= 4) {
		if  (USB_Rx_Cnt >= 4) {
//			unsigned int target = (unsigned int)usbWaitReset | 0x1;
			//gpio_write_bit(GPIOB, 2,0); //LED off when start board
			PMAToUserBufferCopy(chkBuf,VCOM_RX_ADDR,4);

			//TxDStringC("chkBuf = "); TxDStringC(chkBuf);TxDStringC("\r\n");
			int i;
//			USB_Bool cmpMatch = TRUE;
			bool cmpMatch = TRUE;
			for (i=0; i<4; i++) {
				if (chkBuf[i] != cmpBuf[i]) {
					cmpMatch = FALSE;
				}
			}

			if (cmpMatch) {
				//UsbVcpDisconnect();
				gpio_write_bit(GPIOC_DEV, 13, 1);
				// [ROBOTIS] STOP ALL MOTORS 20160111
				gpio_write_bit(GPIOB_DEV, 0, 0);
				gpio_write_bit(GPIOB_DEV, 1, 0);
				gpio_write_bit(GPIOB_DEV, 6, 0);
				gpio_write_bit(GPIOB_DEV, 7, 0);
				uDelay(10000);
				iwdg_init(IWDG_PR_DIV_4 ,10); //Watchdog reset [ROBOTIS]
						/*  asm volatile("mov r0, %[stack_top]      \n\t"             // Reset the stack
	                       "mov sp, r0                \n\t"
	                       "mov r0, #1                \n\t"
	                       "mov r1, %[target_addr]    \n\t"
	                       "mov r2, %[cpsr]           \n\t"
	                       "push {r2}                 \n\t"             // Fake xPSR
	                       "push {r1}                 \n\t"             // Target address for PC
	                       "push {r0}                 \n\t"             // Fake LR
	                       "push {r0}                 \n\t"             // Fake R12
	                       "push {r0}                 \n\t"             // Fake R3
	                       "push {r0}                 \n\t"             // Fake R2
	                       "push {r0}                 \n\t"             // Fake R1
	                       "push {r0}                 \n\t"             // Fake R0
	                       "mov lr, %[exc_return]     \n\t"
	                       "bx lr"
	                       :
	                       : [stack_top] "r" (STACK_TOP),
	                         [target_addr] "r" (target),
	                         [exc_return] "r" (EXC_RETURN),
	                         [cpsr] "r" (DEFAULT_CPSR)
	                       : "r0", "r1", "r2");
	           //should never get here
				                                                 * */
			}
		}
	}
	else if(0) // not used. commented jason ver 32 20160902
	{
		//GPIOA_DEV->regs->ODR = GPIOA_DEV->regs->ODR ^ BIT(14);
		if(usbRxDataWritePointer + USB_Rx_Cnt  < USB_RX_DATA_BUFFER_SIZE)
		{
			for(usbRxDataWriteCounter = 0; usbRxDataWriteCounter < USB_Rx_Cnt; usbRxDataWriteCounter++)
				usbRxDataBuffer[usbRxDataWritePointer + usbRxDataWriteCounter] = USB_Rx_Buffer[usbRxDataWriteCounter];
			usbRxDataWritePointer = usbRxDataWritePointer + USB_Rx_Cnt;
			//LED_CHANGE(LED_RED);
			//		toggleTemp = 1 - toggleTemp;
			//		if(toggleTemp == 1)
			//			GPIO_ResetBits(GPIOB, GPIO_Pin_9); //Status LED ON
			//		else
			//			GPIO_SetBits(GPIOB, GPIO_Pin_9);//Status LED OFF
		}
		else
		{
			for(usbRxDataWriteCounter = 0; usbRxDataWriteCounter < USB_RX_DATA_BUFFER_SIZE - usbRxDataWritePointer; usbRxDataWriteCounter++)
				usbRxDataBuffer[usbRxDataWritePointer + usbRxDataWriteCounter] = USB_Rx_Buffer[usbRxDataWriteCounter];
			for(usbRxDataWriteCounter = 0; usbRxDataWriteCounter < usbRxDataWritePointer + USB_Rx_Cnt - USB_RX_DATA_BUFFER_SIZE; usbRxDataWriteCounter++)
				usbRxDataBuffer[usbRxDataWriteCounter] = USB_Rx_Buffer[USB_RX_DATA_BUFFER_SIZE - usbRxDataWritePointer + usbRxDataWriteCounter];
			usbRxDataWritePointer = usbRxDataWritePointer + USB_Rx_Cnt;
			usbRxDataWritePointer = usbRxDataWritePointer & (USB_RX_DATA_BUFFER_SIZE - 1);
		}
	}

	if(userUsbInterrupt != NULL){

		// SetEPRxCount(VCOM_RX_ENDP,VCOM_RX_EPSIZE);
		//SetEPRxStatus(VCOM_RX_ENDP,EP_RX_VALID);  //it must declared after receiving data from PC
		userUsbInterrupt(&USB_Rx_Buffer[0], USB_Rx_Cnt & 0xFF); //1 byte is enough to express number of count in newBytes
	}

  /* Enable the receive of data on EP3 */
  SetEPRxValid(ENDP3);
}

//bool WriteFlash64(uint8* RxBuffer, u16 RxCount )
bool WriteFlash128()
{
	/*
	u16 RxCount = 0;
	if(usbRxFlashWritePointer >= usbRxFlashReadPointer)
		RxCount = usbRxFlashWritePointer - usbRxFlashReadPointer;
	else
		RxCount = usbRxFlashWritePointer + USB_RX_DATA_BUFFER_SIZE - usbRxFlashReadPointer;

	if((gbFlashDownloadStart == TRUE && RxCount < FLASH_HALF_PAGE_SIZE) || gbIsFlashLock == TRUE) // If flash is lock, stop to write flash. OR if new data is less than 128byte, quit.
		return FALSE;

	u8 Data[FLASH_HALF_PAGE_SIZE + 1] = {0,};
	u16 count = 0;
	u8 index = 0;
	while(1)
	{
		if(usbRxFlashReadPointer == usbRxFlashWritePointer)
			break;
		else if(usbRxFlashReadPointer < usbRxFlashWritePointer)
		{
			if(usbRxFlashReadPointer + FLASH_HALF_PAGE_SIZE <= usbRxFlashWritePointer)
			{
				for(index = 0; index < FLASH_HALF_PAGE_SIZE; index++)
				{
					Data[index] = usbRxFlashBuffer[usbRxFlashReadPointer++];
					usbRxFlashReadPointer &= USB_RX_DATA_BUFFER_SIZE - 1;
				}

			}
			else if(gbFlashDownloadStart == FALSE)
			{
				for(index = usbRxFlashReadPointer; index < usbRxFlashWritePointer; index++)
				{
					Data[index - usbRxFlashReadPointer] = usbRxFlashBuffer[index];
				}
				usbRxFlashReadPointer = usbRxFlashWritePointer;
			}
			else
				break;
		}
		else
		{
			if(usbRxFlashReadPointer + FLASH_HALF_PAGE_SIZE <= usbRxFlashWritePointer + USB_RX_DATA_BUFFER_SIZE)
			{
				for(index = 0; index < FLASH_HALF_PAGE_SIZE; index++)
				{
					Data[index] = usbRxFlashBuffer[usbRxFlashReadPointer++];
					usbRxFlashReadPointer &= USB_RX_DATA_BUFFER_SIZE - 1;
				}

			}
			else if(gbFlashDownloadStart == FALSE)
			{
				for(index = usbRxFlashReadPointer; index < usbRxFlashWritePointer; index++)
				{
					Data[index - usbRxFlashReadPointer] = usbRxFlashBuffer[index];
				}
				usbRxFlashReadPointer = usbRxFlashWritePointer;
			}
			else
				break;
		}

		//TxDByte('^');


		SysTick->CTRL = 0;

		FLASH_ClearFlag(FLASH_FLAG_EOP|FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR
				| FLASH_FLAG_SIZERR | FLASH_FLAG_OPTVERR | FLASH_FLAG_OPTVERRUSR);

		volatile FLASH_Status FLASHStatus;
		FLASHStatus = FLASH_ProgramHalfPage(lStartBlockAddress, (uint32 *)Data);

		SysTick_Config(SystemCoreClock / 1000);

		if(FLASHStatus == FLASH_COMPLETE)
		{
			lStartBlockAddress = lStartBlockAddress + FLASH_HALF_PAGE_SIZE;
		}
		else
		{
			FLASH_ClearFlag(FLASH_FLAG_EOP|FLASH_FLAG_WRPERR | FLASH_FLAG_PGAERR
					| FLASH_FLAG_SIZERR | FLASH_FLAG_OPTVERR | FLASH_FLAG_OPTVERRUSR);
			TxDString("\r\n Download Failed!");
			break;
		}
	}
*/
	return FALSE;
}


/*******************************************************************************
* Function Name  : SOF_Callback / INTR_SOFINTR_Callback
* Description    :
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/
void SOF_Callback(void)
{
  static uint32 FrameCount = 0;
  
  if(bDeviceState == CONFIGURED)
  {
    if (FrameCount++ == VCOMPORT_IN_FRAME_INTERVAL)
    {
      /* Reset the frame counter */
      FrameCount = 0;
      
      /* Check the data to be sent through IN pipe */
      Handle_USBAsynchXfer();  //  [ROBOTIS] commented 20151230
    }
  }  
}

extern void USB_TxDByte(u8 dat)
{
	//TxDByte(dat);
	//Delay(1); //some delay is needed when data send to USB Host by sm6787@robotis.com
	word wCount=0;
	//GPIO_ResetBits(PORT_SLEEP, PIN_SLEEP);
	// pc���� �ӵ��� ���� usb ��Ʈ������ ��� 1ms ����, ���� usb ��Ʈ������ ��� 100ms ���� �ҿ�ȴ�.
	while( ((EP1R & EP_TX_VALID) == EP_TX_VALID )  && wCount < 1000 ) // 1000 = 2.5ms
	{
		uDelay(1);
		wCount++;
	}
	UserToPMABufferCopy(&dat, ENDP1_TXADDR,1);
	SetEPTxCount(ENDP1, 1);
	SetEPTxValid(ENDP1);
}

extern void USB_TxDBytes(u8 * Addr, u16 NofBytes)
{
	u16 wCount=0;
	while(NofBytes > 64)
	{
		UserToPMABufferCopy(Addr, ENDP1_TXADDR,64);  // bug fixed : NofBytes -> 64 jason 20151119 ver 1_44
		SetEPTxCount(ENDP1, 64);  // bug fixed : NofBytes -> 64 jason 20151119 ver 1_44
		SetEPTxValid(ENDP1);
		Addr += 64;
		NofBytes -= 64;
		//GPIO_ResetBits(PORT_SLEEP, PIN_SLEEP);
		// pc���� �ӵ��� ���� usb ��Ʈ������ ��� 1ms ����, ���� usb ��Ʈ������ ��� 100ms ���� �ҿ�ȴ�.
		wCount=0;
		// /*&& wCount < 1000*/ jason 20151119 ver 1_45

		// commented for test. It is bad for USB OTG. jason 20151130 ver 6_3
		while( ((EP1R & EP_TX_VALID) == EP_TX_VALID )  /*&& wCount < 1000*/ ) // 1000 = 2.5ms
		{
			uDelay(10);  // modified 1 -> 10 ver 6_3
			wCount++;
		}
	}
	UserToPMABufferCopy(Addr, ENDP1_TXADDR,NofBytes);
	SetEPTxCount(ENDP1, NofBytes);
	SetEPTxValid(ENDP1);
	//GPIO_ResetBits(PORT_SLEEP, PIN_SLEEP);
	// pc���� �ӵ��� ���� usb ��Ʈ������ ��� 1ms ����, ���� usb ��Ʈ������ ��� 100ms ���� �ҿ�ȴ�.
	wCount=0;
	// /*&& wCount < 1000*/ jason 20151119 ver 1_45

	// commented for test. It is bad for USB OTG. jason 20151130 ver 6_3
	while( ((EP1R & EP_TX_VALID) == EP_TX_VALID )  /*&& wCount < 1000*/ ) // 1000 = 2.5ms
	{
		uDelay(10);  // modified 1 -> 10 ver 6_3
		wCount++;
	}
}

extern USB_Received_Bytes(void)
{
	return USB_Rx_Cnt;
}

u32 Dummy(u32 tmp)
{
	return tmp;
}

void uDelay(u32 uTime) {
	u32 cnt, max;
	static u32 tmp = 0;

	for( max=0; max < uTime; max++)
	{
		for( cnt=0; cnt < 10 ; cnt++ )
		{
			tmp +=Dummy(cnt);
		}
	}
	//tmpdly = tmp;
}
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

