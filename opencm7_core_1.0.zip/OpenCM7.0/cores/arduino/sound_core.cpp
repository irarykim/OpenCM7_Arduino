/***********************************************************************
* Copyright 2017 ROBOTIS Co.,Ltd.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
* 
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
***********************************************************************/

/*
 * sound.c
 *
 *  Created on: 2011. 2. 17.
 *      Author: Administrator
 */

#include "sound_core.h"

//#include "includes.h"
//#include "pwm.h"

#define BUZZER_TIMER	TIM4




void PlayMusic(void);
void PlayDoremi(void);



volatile uint8 gbitRinging = 0;
volatile uint8* gbpSoundPointer;
volatile uint8 gbSoundLengthCount;
volatile uint8 gbitPauseSound = 0;
volatile uint8 gbSoundSpeed;
volatile uint8 gbitWave;
volatile uint16 gwWaveChangeTimer;
volatile uint16 gwWaveChange;
volatile uint8 gbBuzzerData;
volatile uint8 gbBuzzerPlayLength = 0;

volatile uint8 gbMicDetectedCount = 0;
volatile uint8 gbitCounting = 0;
volatile uint8 gbSoundTimeCount;
volatile uint8 gbTempSoundDetectedCount = 0;
volatile uint8 gbSoundDetectedCount = 0;
volatile uint8 gbSoundOffDelay = 0;




enum  {high1=1,la0_,si0,do1,do1_,le1,le1_,mi1,fa1,fa1_,sol1,sol1_,la1,la1_,si1,
	   do2,do2_,le2,le2_,mi2,fa2,fa2_,sol2,sol2_,la2,high2,		low0,		low1};
#define SOUND_NUM 29 /*27*/
enum  { S_CONTINUE=SOUND_NUM,S_OFF,S_WAVE };


#define MD_LENGTH_DIGIT  0x20
#define _16 (1*MD_LENGTH_DIGIT)
#define _8  (2*MD_LENGTH_DIGIT)
#define _4  (4*MD_LENGTH_DIGIT)
#define _2  (0*MD_LENGTH_DIGIT)

#define _8h (3*MD_LENGTH_DIGIT)
#define _4h (6*MD_LENGTH_DIGIT)

const uint16 gwpSoundTable[] =
{
1 	,
1500 	,
8584 	,
8099 	,
7645 	,
7220 	,
6811 	,
6428 	,
6067 	,
5727 	,
5406 	,
5102 	,
4816 	,
4545 	,
4290 	,
4050 	,
3822 	,
3608 	,
3405 	,
3214 	,
3034 	,
2863 	,
2703 	,
2551 	,
2408 	,
2273 	,
1800 	,
25000 	,
12500

};

const uint16 gwpDoremiTable[] =
{
18183 	,
17168 	,
16199 	,
15291 	,
14440 	,
13623 	,
12856 	,
12135 	,
11455 	,
10812 	,
10204 	,
9632 	,
9092 	,
8584 	,
8100 	,
7646 	,
7220 	,
6812 	,
6428 	,
6068 	,
5728 	,
5407 	,
5103 	,
4816 	,
4546 	,
4291 	,
4051 	,
3823 	,
3608 	,
3406 	,
3215 	,
3035 	,
2864 	,
2704 	,
2552 	,
2408 	,
2274 	,
2146 	,
2026 	,
1912 	,
1804 	,
1702 	,
1608 	,
1518 	,
1432 	,
1352 	,
1276 	,
1204 	,
1136   ,

1072   , // added jason 20160526 ver 12_10 OpenCM7.0
1012   ,
956

};

#define SOUND_MAX_LENGTH    35
#define MAX_SOUND_NUM   	25

uint8 gbpSoundBuffer[SOUND_MAX_LENGTH];

#define S_DELTA0    0

const uint8 gbpMusic0[] = {
    8,
    S_DELTA0+do1+_8,
    S_DELTA0+le1+_8,
    S_DELTA0+mi1+_8,
    S_DELTA0+fa1+_8,
    S_DELTA0+sol1+_8,
    S_DELTA0+la1+_8,
    S_DELTA0+si1+_8,
    S_DELTA0+do2+_8,
    0
};


const uint8 gbpMusic1[] = {
	8,
	S_DELTA0+do2+_8,
	S_DELTA0+si1+_8,
	S_DELTA0+la1+_8,
	S_DELTA0+sol1+_8,
	S_DELTA0+fa1+_8,
	S_DELTA0+mi1+_8,
	S_DELTA0+le1+_8,
	S_DELTA0+do1+_2,
	0
};

#define S_DELTA6 4
const uint8 gbpMusic6[] = {
    15,
    S_DELTA6+do1+_8,
    S_DELTA6+fa1+_8,
    S_DELTA6+la1+_8,
    S_DELTA6+do2+_8h,

    S_OFF+_16,
    S_DELTA6+la1+_8,
    S_DELTA6+do2+_2,
    S_CONTINUE+_8,
    S_OFF+_8,

    S_DELTA6+do2+_8,
    S_OFF+_8,
    S_DELTA6+do2+_16,
    S_DELTA6+do2+_16,
    S_DELTA6+do2+_8,
    S_OFF+_8,
    S_DELTA6+do2+_8,

    S_DELTA6+fa2+_2,

    S_OFF+_4,
    0
};


#define S_DELTA8 12
const uint8 gbpMusic7[] = {
	23,
	S_DELTA8+do1+_8,
	S_OFF+_16,
	S_DELTA8+do1+_16,
	S_DELTA8+do1+_16,
	S_DELTA8+do1+_8,
	S_DELTA8+do1+_8,
	S_DELTA8+sol1+_8,
	S_DELTA8+mi1+_8,
	S_DELTA8+sol1+_8,
	S_DELTA8+mi1+_8,
	S_DELTA8+do1+_2,
	S_OFF+_8,
	0
};

const uint8 gbpSound0[] = {
    20,
    do2+_16,
    S_WAVE+_8h,+8,
    S_CONTINUE+_8,
    S_WAVE+_8h,(uint8)-8,
    S_WAVE+_16,+12,
    S_WAVE+_16,(uint8)-12,

    S_OFF+_8,
    0
};


const uint8 gbpSound1[] = {
    20,
	mi1+_8,
            S_WAVE+_8,+4,
            S_WAVE+_2,(uint8)-2,

            S_CONTINUE+_2,
            S_CONTINUE+_4,

    S_OFF+_8,
    0
};

const uint8 gbpSound2[] = {
    16,
    sol2+_16,
    S_WAVE+_16,+18,
    S_WAVE+_16,(uint8)-18,
    S_OFF+_16,
    S_WAVE+_16,+18,
    S_WAVE+_16,(uint8)-18,

    0
};

const uint8 gbpSound3[] = {
    32,
    fa1_+_8,
            S_WAVE+_2,1,
            S_CONTINUE+_4,

    S_OFF+_8,
    0
};

const uint8 gbpSound4[] = {
    20,
    sol2_ +_8,
            S_WAVE+_16,+1,
            S_WAVE+_4,(uint8)-1,


    S_OFF+_8,
    0
};

const uint8 gbpSound5[] = {
    16,
    sol2_ +_8,
            S_WAVE+_4,+3,
            S_WAVE+_4,(uint8)-3,
            S_WAVE+_4,+3,
            S_WAVE+_4,(uint8)-3,


    S_OFF+_8,
    0
};

const uint8 gbpSound6[] = {
    20,
    do2 +_16,
            S_WAVE+_2,(uint8)-12,
    //        S_CONTINUE+_2,  // commented jason 20151116 ver 40
    0
};

const uint8 gbpSound7[] = {
    20,
    high2 +_16,
            S_WAVE+_2,(uint8)-1,
            S_WAVE+_2,+1,


    S_OFF+_8,
    0
};


const uint8 gbpSound8[] = {
    16,
    high1 +_16,
    S_WAVE+_16,(uint8)-1,
    high2 +_16,
    S_WAVE+_16,(uint8)-1,
    S_WAVE+_16,+1,


    S_OFF+_8,
    0
};

const uint8 gbpSound10[] = {
    16,
    high2+_8,
    S_WAVE+_8,(uint8)-10,

    S_OFF+_8,

    0
};

const uint8 gbpSound11[] = {
    16,
    high2+_16,
    S_WAVE+_16,+10,
    S_WAVE+_16,(uint8)-10,
    S_OFF+_8,
    0
};

const uint8 gbpSound12[] = {
    16,
    high2+_16,
    S_WAVE+_16,+10,
    S_WAVE+_16,(uint8)-10,
    S_OFF+_16,
    S_WAVE+_16,+10,
    S_WAVE+_16,(uint8)-10,

    0
};

const uint8 gbpSound13[] = {
    8,
    mi2 +_16,
    S_WAVE+_16,+5,
    sol2 +_4,
    mi2 +_4,
    S_WAVE+_16,+5,
    sol2 +_4,
    mi2 +_4,


    S_OFF+_8,
    0
};
#define S_DELTA15 0
const uint8 gbpSound15[] = {
    9,
    S_OFF+_2,
    S_DELTA15+la1_+_4,
    S_OFF+_16,

    S_DELTA15+la0_+_8h,
    S_DELTA15+la0_+_8h,
    S_DELTA15+la0_+_8h,
    S_OFF+_2,
    0
};

#define S_DELTA15 0
const uint8 gbpSound20[] = {
	16,
	low1 +_16,
	S_WAVE+_2,+50,
	S_OFF+_8,
    0
};


const uint8 gbpSound21[] = {
	4,
	high1 +_16,
	S_WAVE+_2,(uint8)-20,
	S_WAVE+_2,+20,
	S_WAVE+_2,(uint8)-40,
	S_WAVE+_2,+40,
	S_OFF+_8,
	0
};

const uint8 gbpSound22[] = {
	1,
	high2 +_16,
	S_WAVE+_2,(uint8)-10,
	S_WAVE+_2,+10,
	S_WAVE+_2,(uint8)-20,
	S_WAVE+_2,+20,
	S_WAVE+_2,(uint8)-30,
	S_WAVE+_2,+30,
	S_WAVE+_2,(uint8)-40,
	S_WAVE+_2,+40,
	S_WAVE+_2,(uint8)-50,
	S_WAVE+_2,+50,
	S_WAVE+_2,(uint8)-60,
	S_WAVE+_2,+60,
	S_WAVE+_2,(uint8)-70,
	S_WAVE+_2,+70,
	S_WAVE+_2,(uint8)-80,
	S_WAVE+_2,+80,
	S_OFF+_8,
	0
};

const uint8 gbpSound23[] = {
	8,
	high1 +_16,
	S_WAVE+_2,(uint8)-8,
	S_WAVE+_2,+1,
	S_OFF+_8,
	0
};


#define S_DELTA24 0
const uint8 gbpSound24[] = {
	4,
	S_DELTA24+la2+_8h,
	S_OFF+_16,
	S_DELTA24+la2+_8h,
	S_OFF+_16,
	S_DELTA24+la2+_8h,
	S_OFF+_16,
	S_DELTA24+la2+_8h,
	S_OFF+_16,
	0
};

#define S_DELTA4 0
const uint8 gbpSound25[] = {
	16,
	S_DELTA4+fa2+_8,

	S_WAVE+_4,(uint8)-18,
	S_WAVE+_4,(uint8)-18,
	S_WAVE+_4,(uint8)-18,

	0
};

#define S_DELTA5 1
const uint8 gbpSound30[] = {
	8,
	high2+_16,
	 high1+_16,
	S_WAVE+_16,(uint8)-8,
	S_WAVE+_4h,2,
	S_WAVE+_4,1,

	0
};

#define S_DELTA7 0
const uint8 gbpSound31[] = {
	7 ,
	S_DELTA7+high1+_16,
	S_DELTA7+fa2-1+_8,
	S_OFF+_16,
	S_DELTA7+high1+_16,
	S_DELTA7+fa2-2+_8,
	S_OFF+_16,
	S_DELTA7+high1+_16,
	S_DELTA7+fa2-3+_8,
	S_OFF+_16,
	S_DELTA7+high1+_16,
	S_DELTA7+fa2-4+_8,
	S_OFF+_16,
	S_DELTA7+high1+_16,
	S_DELTA7+fa2-5+_8,
	0
};

const uint8* gbpSoundArray[] = {gbpMusic0,gbpMusic1,gbpMusic6,gbpMusic7,gbpSound0,gbpSound1,gbpSound2,gbpSound3,
	gbpSound4,gbpSound5,gbpSound6,gbpSound7,gbpSound8,gbpSound10,gbpSound11,gbpSound12,gbpSound13,//gbpSound14,
	gbpSound15,gbpSound20,gbpSound21,gbpSound22,gbpSound23,gbpSound24,gbpSound25,gbpSound30,gbpSound31 };

void SetupBuzzer(void)
{
	pinMode(13, PWM);
	Timer4.pause();
	Timer4.setPrescaleFactor(8);
	Timer4.setOverflow(2000);

	Timer10.pause();
	Timer10.setPeriod(3900);
	Timer10.setMode(TIMER_CH1, TIMER_OUTPUT_COMPARE);
	Timer10.setCompare(TIMER_CH1, 1);
	Timer10.attachInterrupt(TIMER_CH1, __ISR_Buzzer_Manage);
	Timer10.refresh();
	Timer10.resume();

	attachInterrupt(22,__ISR_MIC_EXTI, FALLING);
	gpio_set_mode(GPIOC_DEV, 14, GPIO_INPUT_FLOATING);
}

void SetBuzzerTimer(uint8 time)
{
	gbBuzzerPlayLength = time;
}

void SetBuzzerIndex(uint8 index)
{
	gbBuzzerData = index;
}

uint8 GetBuzzerTimer(void)
{
	return gbBuzzerPlayLength;
}

void __ISR_Buzzer_Manage(void)
{
	uint8 bHight;
    uint8 bSoundSpd;
    uint16 wWaveChg;

	if( gbitRinging )
	{
        if(!--gbSoundLengthCount)
		{
			bHight = *gbpSoundPointer++;
			if(!bHight)
			{
				SOUND_OFF;
				gbitRinging = 0;
				gbSoundOffDelay = 2;
				//MIC_ON;
			}
			else
			{
				bSoundSpd = gbSoundSpeed;
				gbSoundLengthCount = bHight>>5;
				bHight &= 0x1f;
				if(gbSoundLengthCount == 0) gbSoundLengthCount = 8;
				gbSoundLengthCount *= bSoundSpd;
				if(bHight < SOUND_NUM)
				{
					gbitWave = 0;
					if(gbitPauseSound)
					{

						SOUND_OFF;
						gbSoundLengthCount = 1; /* every music unit, 4msec pause*/
						gbitPauseSound = 0;
						gbpSoundPointer--;
					}
					else
					{

						SOUND_ON;
						gbitPauseSound = 1;
						if( gbBuzzerPlayLength == 0xFF )
						{
							//porting - end
							//OCR1A = gwpSoundTable[ bHight ];
							SetBuzzer(gwpSoundTable[ bHight ]);
						}
						else
						{
							//porting -end
							//OCR1A = gwpDoremiTable[ gbBuzzerData ];
							SetBuzzer(gwpDoremiTable[ gbBuzzerData ]);

						}
					}
				}
				/*
				else if(bHight==S_CONTINUE)
				{

				}
				*/
				else if(bHight==S_OFF)
				{
					gbitWave = 0;
					SOUND_OFF;
				}
				else if(bHight==S_WAVE)
				{
					SOUND_ON;
					gbitWave = 1;

					//porting - check
					//gwWaveChangeTimer = OCR1A;
					gwWaveChangeTimer = BUZZER_TIMER->ARR;
					gwWaveChange = *gbpSoundPointer++;
					if(gwWaveChange > 0x80) gwWaveChange |= 0xff00;
//						if(gwWaveChange & 0x80) gwWaveChange |= 0xff00;
				}
			}
		}
		else if(gbitWave)
		{
			wWaveChg = gwWaveChange;
                            /*if(wTimer > 0xa000 && wTimer < 0xffa0)*/
			gwWaveChangeTimer += wWaveChg;
			//porting -end
			//OCR1A = gwWaveChangeTimer;
			SetBuzzer(gwWaveChangeTimer);
		}
	}
	else
	{
		if( gbSoundOffDelay != 0 )
		{
			if( gbSoundOffDelay > 1 )
				gbSoundOffDelay--;
			else
			{
				gbSoundOffDelay = 0;
				gbBuzzerPlayLength = 0;

				SOUND_OFF;
				//porting - end
				MIC_ON;
			}
		}
	}

	if( gbitCounting )
	{
		if( gbSoundTimeCount > 200 )
		{
			gbSoundDetectedCount = gbTempSoundDetectedCount;
			gbTempSoundDetectedCount = 0;
			gbitCounting = 0;
		}
		else gbSoundTimeCount++;
	}
}

void SetBuzzer(uint16 periodUs)
{
	//periodUs /= 2;
//	TIM_SetAutoreload(BUZZER_TIMER, periodUs);
//	TIM_SetCompare1(BUZZER_TIMER, periodUs / 2);
	Timer4.setOverflow(periodUs);
	Timer4.setCompare(3, periodUs / 2);

}




void PlayMusic(void)
{
	MIC_OFF;
	gbpSoundPointer = gbpSoundBuffer;
	gbSoundSpeed = *gbpSoundPointer++;
	gbitRinging = 1;
	gbitPauseSound = 0;

	//SetBuzzer(0);
	//SOUND_OFF; //SOUND_OFF; instead of SetBuzzer(0); 20160908 ver 38

	gbSoundLengthCount = 1;
	SOUND_ON;
}

void PlayDoremi(void)
{
	uint8 length, i, start = 0, cnt;

    if( gbBuzzerPlayLength != 0xFF )
    {
        if( gbBuzzerData > 51 ) gbBuzzerData = 51;
        if( gbBuzzerPlayLength > 50 )
            length = 50;
        else
            length = gbBuzzerPlayLength;

        if( gbBuzzerPlayLength == 0x0 )
        {
            gbBuzzerPlayLength = length = 3;
        }

        gbpSoundBuffer[0] = 25;
		i = 1;

      	while( length >= 8 )
		{
			length -= 8;
			if( start == 1 )
				gbpSoundBuffer[i++] = S_CONTINUE+_2;
			else
			{
				gbpSoundBuffer[i++] = 20+_2;
				start = 1;
			}
		}

        for( cnt=0; cnt<3; cnt++ )
        {
			if( length & (0x04>>cnt) )
			{
				if( start == 1 )
					gbpSoundBuffer[i++] = S_CONTINUE+(_4>>cnt);
				else
				{
					gbpSoundBuffer[i++] = 20+(_4>>cnt);
					start = 1;
				}
			}
		}

        gbpSoundBuffer[i] = 0;
        PlayMusic();
    }
    else
    if( gbBuzzerData < MAX_SOUND_NUM )
    {
		for( i=0; i<SOUND_MAX_LENGTH; i++ )
			gbpSoundBuffer[i] = gbpSoundArray[gbBuzzerData][i];

        PlayMusic();
    }
}

uint8 GetSoundDetectedCount(void)
{
	return gbSoundDetectedCount;
}

void ClearSoundDetectedCount(void)
{
	gbSoundDetectedCount = 0;
	gbitCounting = 0;
	gbTempSoundDetectedCount = 0;
}

uint8 GetSoundDetectingCount(void)
{
	return gbTempSoundDetectedCount;
}

void _MIC_ON(void)
{
	attachInterrupt(22,__ISR_MIC_EXTI, FALLING);
}


void _MIC_OFF(void)
{
	detachInterrupt(22);
}


void __ISR_MIC_EXTI(void)
{
    if( gbitCounting == 0 )
    {
        gbitCounting = 1;
        gbSoundTimeCount = 0;
        gbTempSoundDetectedCount = 1;
    }
    else
    {
        gbSoundTimeCount = 0;
        gbTempSoundDetectedCount++;
    }

    gbSoundOffDelay = 20;
    MIC_OFF;

}



